//#############################################################################
//
// FILE: psfbpcmc_main.c
//
// TITLE: This is the main file for the solution, following is the
//         <solution>.c -> solution source file
//         <solution>.h -> solution header file
//         <solution>_settings.h -> powerSUITE generated settings
//         <solution>_hal.c -> solution hardware abstraction layer
//         <solution>_hal.h -> solution hardware abstraction layer header file
//         <solution>_clatask.cla -> cla task file
//
//#############################################################################
// $TI Release: TIDM_02000 v1.00.00.00 $
// $Release Date: Tue Nov  3 10:37:55 CST 2020 $
// $Copyright:
// Copyright (C) 2020 Texas Instruments Incorporated - http://www.ti.com/
//
// ALL RIGHTS RESERVED
// $
//#############################################################################

#include "psfbpcmc.h"

//
// Globals
//
//volatile uint32_t *gpioDataReg_12;
//uint32_t pinMask_12;
//float32_t g_phase_hr;
//float32_t g_duty_hr;
//uint32_t g_duty_hr_frac=0;

//volatile uint16_t adcAResult_Cur;
volatile uint16_t adcBResult_Out_Vol;
volatile uint16_t adcCResult_Ac_Vol;
//uint16_t adc_result_update_Cur;
uint16_t adc_result_update_Out_Vol;
uint16_t adc_result_update_Ac_Vol;

uint32_t cpuTimer0IntCount = 0;
//uint16_t PIgaintuning_Transient_cnt;
//uint16_t PIgaintuning_Steady_cnt;

uint16_t DAB_control_start_flag = STOP_PI;
uint16_t adc_update_flag = UPDATE_NOT_DONE;
uint16_t pi_update_flag = UPDATE_NOT_DONE;
uint16_t DAB_PI_Softstart_Flag = NONE_SOFTSTART;
uint16_t Ramp_active_flag;
uint16_t Voltage_REF_update;
uint16_t Voltage_REF_update_Pre;

uint16_t Run_Indeed_Flag    =   RUN_NOT_YET;

uint16_t cmpss_dac_ref_high;
uint16_t cmpss_dac_ref_low;

// This is a structure to save related PI() calculation
typedef struct PI_str {
    float32_t voltage_ref;                          // Voltage reference
    float32_t voltage_out_meas;            // Real voltage measurement

    float32_t voltage_ac_meas;            // Real voltage measurement

    //float32_t current_ind_meas;            // Real voltage measurement

    float32_t P_err_V;                                // Error in PI loop (voltage_ref - voltage_meas)
    float32_t I_err_sum_V;                            // Sum of I term's error

    float32_t P_func_V;
    float32_t I_func_V;
    float32_t PI_total_func_V;

    float32_t P_factor_V;
    float32_t I_factor_V;

    //float32_t duty_cal;

    float32_t Iref;
    float32_t Iref_high_cal;
    float32_t Iref_low_cal;

    float32_t Voltage_REF_Set;

}PI_controller;

PI_controller   DAB_PI_Ctrl;

void DAB_globalVariablesInit();
void adc_reading (uint16_t No_Of_Samples);
void PI_Dynamic_Gain_Ctrl (void);
void PI_Linear_For_Constant_Voltage (void);
//void Duty_Conversion (void);
//void Phase_Conversion (void);
//void Phase_Output (void);
//void SoftStart_RampUp_WihtoutPI (void);
//void Voltage_Calib (void);
void SCI_Init (uint32_t baudrate);
void DAB_HAL_setupDevice(void);
void initCMPSS(uint32_t base);
void CMPSS_Ref_Set (uint32_t base);
//void Init_Ext_ISR (void);

/************************* Definition *************************
 * Function name: cpuTimer0ISR
 * Description: This is an ISR of external interrupt on the pin
 * Variables:
 * - None
* Return: None
 **************************************************************/
#if (0)
__interrupt void gpioInterruptHandler1(void)
{
    //GPIO_togglePin(DAB_DEBUG_IO);
    gpioDataReg_12[GPIO_GPxSET_INDEX] = pinMask_12;
    //Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
    HWREGH(PIECTRL_BASE + PIE_O_ACK) = INTERRUPT_ACK_GROUP1;
}
#endif
/************************* Definition *************************
 * Function name: cpuTimer0ISR
 * Description: This is an ISR of Timer 0 and is called periodically
 *              for PI () calculation
 * Variables:
 * - None
* Return: None
 **************************************************************/
__interrupt void cpuTimer0ISR(void)
{
    //if (DAB_control_start_flag == START_PI)
    {
        //gpioDataReg_12[GPIO_GPxCLEAR_INDEX] = pinMask_12;
        // PI update acknowledgement
        pi_update_flag = UPDATE_DONE;
    }
    //
    // Acknowledge this interrupt to receive more interrupts from group 1
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
}

void main(void)
{
    //unsigned char *msg;
    // This routine sets up the basic device config such as initializing PLL
    // copying code from FLASH to RAM. This routine will also initialize the
    // CPU timers that are used in the background task for this system
    // Make sure LSP clock is set to divide by 2 to get get 50MHz.


    DAB_HAL_setupDevice();

    // Initialize global variables generic to the board
    DAB_globalVariablesInit();

    // Setup all PWMs
    //PSFB_HAL_setupPWMs();

    // Setup GPIOs
    PSFB_HAL_setupGPIOs();
    GPIO_writePin(DAB_DEBUG_IO, 0);

    //gpioDataReg_12 = (uint32_t *)((uintptr_t)GPIODATA_BASE) +
    //                  ((12 / 32U) * GPIO_DATA_REGS_STEP);
    //pinMask_12 = (uint32_t)1U << (12 % 32U);

    // Setup ADC on the device
    // ADC SOC Trigger by SW
    PSFB_HAL_setupADC();

    // Set up COMP1H and COMP1L
    initCMPSS(CMPSS3_BASE);

    // Initialize external ISR
    //Init_Ext_ISR();

    // Enable PWM Clocks
    //PSFB_HAL_enablePWMCLKCounting();

    // safe to setup PWM pins
    //PSFB_HAL_setPinsAsPWM();

    // Call to init UART for communicating with PC
    //SCI_Init(SCI_BAUDRATE_SET);

    //g_phase_hr=(float32_t)PHASE_DEFAULT_HR; // 0 50
    //Phase_Output();

    // Assign initial Kp, Ki
    PI_Dynamic_Gain_Ctrl();

    // Add a delay (5 seconds)
    DEVICE_DELAY_US(1000000);
    //DEVICE_DELAY_US(1000000);
    //DEVICE_DELAY_US(1000000);
    //DEVICE_DELAY_US(1000000);
    //DEVICE_DELAY_US(1000000);

    // ISR Mapping
    PSFB_HAL_setupInterrupt();

    // Set to 0% duty before running
    //DAB_PI_Ctrl.duty_cal = 0.0000f;
    //Duty_Conversion();
    /*DEVICE_DELAY_US(1000000);
    DEVICE_DELAY_US(1000000);
    DEVICE_DELAY_US(1000000);
    DEVICE_DELAY_US(1000000);
    DEVICE_DELAY_US(1000000);
    DEVICE_DELAY_US(1000000);
    DEVICE_DELAY_US(1000000);
    DEVICE_DELAY_US(1000000);
    DEVICE_DELAY_US(1000000);
    DEVICE_DELAY_US(1000000);*/
    /*************************************** NOTES *************************
     * This flag is used to allow soft-start function for DAB converter
     * DAB_PI_Softstart_Flag = NONE_SOFTSTART --> soft-start is not allowed
     * DAB_PI_Softstart_Flag = SOFTSTART_WITH_PI_RUNNING
     * --> allows soft-start with PI function running
     * DAB_PI_Softstart_Flag = SOFTSTART_WITH_OPEN_LOOP_RAMP_UP_REF_VOLTAGE
     * --> allows soft-start with PI function stopping; reference voltage is
     * increased opep-loop by ramp function
     ***********************************************************************/
    //DAB_PI_Softstart_Flag = SOFTSTART_WITH_OPEN_LOOP_RAMP_UP_REF_VOLTAGE;

    // To start PI loop for DAB converter
    //DAB_control_start_flag = START_PI;

    // For testing purpose
    // Send starting message.
    //
    //msg = "\r\n\n\nHello World!\0";
    //SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 17);
    //msg = "\r\nYou will enter a character, and the DSP will echo it back!\n\0";
    //SCI_writeCharArray(SCIA_BASE, (uint16_t*)msg, 62);


    DAB_PI_Ctrl.Voltage_REF_Set = DAB_Voltage_REF;
    Voltage_REF_update = (uint16_t)DAB_PI_Ctrl.Voltage_REF_Set;
    Voltage_REF_update_Pre=Voltage_REF_update;

    //DAB_control_start_flag = START_PI;
    //DAB_PI_Ctrl.duty_cal = 0.596f;

    while (DAB_control_start_flag != START_PI){};

    DEVICE_DELAY_US(1000000);
    GPIO_writePin(DAB_DEBUG_IO, 1);

    while (1)
    {
        if (pi_update_flag == UPDATE_DONE)
        {
            // Clear flar and wait for next Timer ISR
            pi_update_flag = UPDATE_NOT_DONE;
            // ADC reading to get the current output voltage of DAB converter -->  It takes xus
            if (DAB_control_start_flag == START_PI)
            {
                //GPIO_writePin(DAB_DEBUG_IO, 1);
                adc_reading(NO_OF_SAMPLES_PER_CONTROL_LOOP);    // Single sample for 2 channels takes 960ns to read

                // Call PI function to calculate a new duty
                PI_Linear_For_Constant_Voltage();
                //GPIO_writePin(DAB_DEBUG_IO, 0);

            }
            else if (DAB_control_start_flag == STOP_PI)
            {
                GPIO_writePin(DAB_DEBUG_IO, 0);
                // PI's variables for voltage
                DAB_PI_Ctrl.I_err_sum_V = 0.0f;
                DAB_PI_Ctrl.PI_total_func_V = 0.0f;
            }
        }
    }
}

/************************* Definition *************************
 * Function name: DAB_globalVariablesInit
 * Description: to initial variables and parameters
 * Variables:
 * - None
* Return: None
 **************************************************************/
void DAB_globalVariablesInit()
{
    cpuTimer0IntCount = 0;
    DAB_control_start_flag = STOP_PI;
    adc_update_flag = UPDATE_NOT_DONE;
    pi_update_flag = UPDATE_NOT_DONE;
    Ramp_active_flag = RAMP_ACTIVE;
    Run_Indeed_Flag = RUN_NOT_YET;

    // PI's variables for voltage
    DAB_PI_Ctrl.I_err_sum_V = 0.0f;
    DAB_PI_Ctrl.PI_total_func_V = 0.0f;

    //g_phase_hr = (float32_t)0.;
    //g_duty_hr = 0.0f;
    //DAB_PI_Ctrl.duty_cal = 0.0f;
}

/************************* Definition *************************
 * Function name: adc_reading
 * Description: to activate ADCB (channel 3) and to get an update
 *              of the voltage measurement
 * Variables:
 * - No_Of_Samples: PWM Number of samples to get one measurement update
* Return: None
 **************************************************************/
void adc_reading (uint16_t No_Of_Samples)
{
    //uint16_t adc_sample_cnt = 0;

    //adcAResult_Cur = 0;
    //adcBResult_Out_Vol = 0;
    //adcCResult_Ac_Vol = 0;

    //for (adc_sample_cnt=0; adc_sample_cnt < No_Of_Samples; adc_sample_cnt++)
    {
        //
        // Convert, wait for completion, and store results
        //
        //HWREGH(ADCA_BASE + ADC_O_SOCFRC1) = (1U << (uint16_t)ADC_SOC_NUMBER5);
        HWREGH(ADCB_BASE + ADC_O_SOCFRC1) = (1U << (uint16_t)ADC_SOC_NUMBER1);
        HWREGH(ADCC_BASE + ADC_O_SOCFRC1) = (1U << (uint16_t)ADC_SOC_NUMBER0);

        //
        // Wait for ADCA to complete, then acknowledge flag
        //
        while(//((HWREGH(ADCA_BASE + ADC_O_INTFLG) & (1U << (uint16_t)ADC_INT_NUMBER1)) == 0U)||
              ((HWREGH(ADCB_BASE + ADC_O_INTFLG) & (1U << (uint16_t)ADC_INT_NUMBER2)) == 0U)||
              ((HWREGH(ADCC_BASE + ADC_O_INTFLG) & (1U << (uint16_t)ADC_INT_NUMBER3)) == 0U)){}

        //Clear interrupt status
        //HWREGH(ADCA_BASE + ADC_O_INTFLGCLR) = 1U << (uint16_t)ADC_INT_NUMBER1;
        HWREGH(ADCB_BASE + ADC_O_INTFLGCLR) = 1U << (uint16_t)ADC_INT_NUMBER2;
        HWREGH(ADCC_BASE + ADC_O_INTFLGCLR) = 1U << (uint16_t)ADC_INT_NUMBER3;
        // Get ADC value
        //adcAResult_Cur += HWREGH(ADCARESULT_BASE + ADC_RESULTx_OFFSET_BASE + ADC_SOC_NUMBER5);
        //adcBResult_Out_Vol += HWREGH(ADCBRESULT_BASE + ADC_RESULTx_OFFSET_BASE + ADC_SOC_NUMBER1);
        //adcCResult_Ac_Vol += HWREGH(ADCCRESULT_BASE + ADC_RESULTx_OFFSET_BASE + ADC_SOC_NUMBER0);
        adc_result_update_Out_Vol = HWREGH(ADCBRESULT_BASE + ADC_RESULTx_OFFSET_BASE + ADC_SOC_NUMBER1);
        adc_result_update_Ac_Vol = HWREGH(ADCCRESULT_BASE + ADC_RESULTx_OFFSET_BASE + ADC_SOC_NUMBER0);
    }
    //adc_result_update_Cur = (uint16_t)(adcAResult_Cur/No_Of_Samples);
    //adc_result_update_Out_Vol = (uint16_t)(adcBResult_Out_Vol/No_Of_Samples);
    //adc_result_update_Ac_Vol = (uint16_t)(adcCResult_Ac_Vol/No_Of_Samples);
}

/************************* Definition *************************
 * Function name: PI_Dynamic_Gain_Ctrl
 * Description: for dynamically controlling Kp, Ki
 * Variables:
 * - None
* Return: None
 **************************************************************/
void PI_Dynamic_Gain_Ctrl (void)
{
    // Can control PI gains w.r.t error or voltage measurement ...
    DAB_PI_Ctrl.P_factor_V = KP_CONST_TRANS_V;
    DAB_PI_Ctrl.I_factor_V = KI_CONST_TRANS_V;

    //DAB_PI_Ctrl.P_factor_C = KP_CONST_TRANS_C;
    //DAB_PI_Ctrl.I_factor_C = KI_CONST_TRANS_C;

}
/************************* Definition *************************
 * Function name: PI_Linear_For_Constant_Voltage
 * Description: to handle PI algorithm to create the updated phase
 * Variables:
 * - None
* Return: None
 **************************************************************/
void PI_Linear_For_Constant_Voltage (void)
{
    // Clear flag to make sure to read a new PI calculation
    // adc_update_flag = UPDATE_NOT_DONE;

    // Calculate the measured voltage
    // Note: Voltage sensing resistors: 7.32k and 1MOhm; 2nF
    DAB_PI_Ctrl.voltage_out_meas = (float32_t)adc_result_update_Out_Vol*DAB_Out_Voltage_Scale_Factor;
    DAB_PI_Ctrl.voltage_ac_meas = (float32_t)adc_result_update_Ac_Vol*Ac_Rec_Voltage_Scale_Factor;

    if (DAB_PI_Ctrl.voltage_out_meas >= (float32_t)(DAB_PI_Ctrl.Voltage_REF_Set*1.2f))
    {
        GPIO_writePin(DAB_DEBUG_IO, 0);
        DAB_control_start_flag = STOP_PI;

        //cmpss_dac_ref_high  = 4095U;
        //cmpss_dac_ref_low   = 4095U;
        //HWREGH(CMPSS3_BASE + CMPSS_O_DACHVALS) = cmpss_dac_ref_high;
        //HWREGH(CMPSS3_BASE + CMPSS_O_DACLVALS) = cmpss_dac_ref_low;
    }
    else
    {
        // Error for the voltage loop
        DAB_PI_Ctrl.P_err_V = DAB_PI_Ctrl.Voltage_REF_Set - DAB_PI_Ctrl.voltage_out_meas;

        // Error sum of I term of the voltage loop
        DAB_PI_Ctrl.I_err_sum_V += DAB_PI_Ctrl.P_err_V;

        // P term - of the voltage loop
        DAB_PI_Ctrl.P_func_V = DAB_PI_Ctrl.P_factor_V*DAB_PI_Ctrl.P_err_V;

        // I term - of the voltage loop
        DAB_PI_Ctrl.I_func_V = (DAB_PI_Ctrl.I_factor_V*DAB_PI_Ctrl.I_err_sum_V)/1000000.0f;

        // PI total - of the voltage loop
        DAB_PI_Ctrl.PI_total_func_V = DAB_PI_Ctrl.P_func_V + DAB_PI_Ctrl.I_func_V;

        DAB_PI_Ctrl.Iref = (float32_t)DAB_PI_Ctrl.PI_total_func_V*DAB_PI_Ctrl.voltage_ac_meas;

        // I ref limit (wind-up effect)
        if (DAB_PI_Ctrl.Iref >= IREF_HIGH_LIMIT) DAB_PI_Ctrl.Iref = IREF_HIGH_LIMIT;
        else if (DAB_PI_Ctrl.Iref <= IREF_LOW_LIMIT) DAB_PI_Ctrl.Iref = IREF_LOW_LIMIT;

        //DAB_PI_Ctrl.Iref = 0.0f;
        cmpss_dac_ref_high   = (uint16_t)(DAB_PI_Ctrl.Iref*IREF_UPPER_RATIO/Inductor_Current_Scale_Factor);
        cmpss_dac_ref_low    = (uint16_t)(DAB_PI_Ctrl.Iref*IREF_LOWER_RATIO/Inductor_Current_Scale_Factor);

        if (cmpss_dac_ref_high >= 4095U)    cmpss_dac_ref_high=4095U;
        if (cmpss_dac_ref_low >= 4095U)    cmpss_dac_ref_low=4095U;

        HWREGH(CMPSS3_BASE + CMPSS_O_DACHVALS) = cmpss_dac_ref_high;
        HWREGH(CMPSS3_BASE + CMPSS_O_DACLVALS) = cmpss_dac_ref_low;
        // Save the current error
        //DAB_PI_Ctrl.pre_err_V = DAB_PI_Ctrl.P_err_V;
        if ((Voltage_REF_update >= (uint16_t)(Voltage_REF_update_Pre+15))|| (Voltage_REF_update <= (uint16_t)(Voltage_REF_update_Pre-15)))
        {
            Voltage_REF_update = Voltage_REF_update_Pre;
        }
        else Voltage_REF_update_Pre = Voltage_REF_update;

        if (Voltage_REF_update >= DAB_Voltage_REF_MAX)
        {
            Voltage_REF_update = DAB_Voltage_REF_MAX;
            Voltage_REF_update_Pre = Voltage_REF_update;
        }

        DAB_PI_Ctrl.Voltage_REF_Set = (float32_t)Voltage_REF_update_Pre;
    }
}

/************************* Definition *************************
 * Function name: Duty_Conversion
 * Description: converts from PI result to a real duty and assign
 *              to HW
 * Variables:
 * - None
* Return: None
 **************************************************************/
#if (0)
void Duty_Conversion (void)
{
    uint32_t  duty_int_val;
    uint32_t  duty_dec_val;

    // Clear flag for a new conversion
    // pi_update_flag = UPDATE_NOT_DONE;

    // Converts from a PI result to phase
    //g_duty_hr = (uint32_t)(DAB_PI_Ctrl.duty_cal * (float32_t)PWM_PERIOD_TICKS_HR_AB);
    g_duty_hr = (DAB_PI_Ctrl.duty_cal * PSFB_FB_PWM_PERIOD_TICKS_HR);
    duty_int_val = (uint32_t)g_duty_hr;
    duty_dec_val = (uint32_t)((g_duty_hr-duty_int_val)*MEP_STEP_DUTY);
    HRPWM_setCounterCompareValue(PSFB_FB_PWM5_BASE, HRPWM_COUNTER_COMPARE_A, (uint32_t)(((duty_int_val & 0xFFFF) << 8U) | (duty_dec_val & 0xFF)));

    //EPWM_setCounterCompareValue(PSFB_FB_PWM5_BASE, EPWM_COUNTER_COMPARE_A, g_duty_hr);
    //HRPWM_setCounterCompareValue(PSFB_FB_PWM5_BASE, HRPWM_COUNTER_COMPARE_A, (uint32_t)(g_duty_hr << 8));
    //HRPWM_setCounterCompareValue(PSFB_FB_PWM3_BASE, HRPWM_COUNTER_COMPARE_A, (uint32_t)(g_duty_hr << 8));
}
#endif
/************************* Definition *************************
 * Function name: Phase_Conversion
 * Description: converts from PI result to a real phase and assign
 *              to HW
 * Variables:
 * - None
* Return: None
 **************************************************************/
/*void Phase_Conversion (void)
{
    // Clear flag for a new conversion
    // pi_update_flag = UPDATE_NOT_DONE;

    // Converts from a PI result to phase
    DAB_PI_Ctrl.phase_cal = (float32_t)DAB_PI_Ctrl.PI_total_func*PHASE_CONVERSION_FACTOR;

    // Apply updated phase to the PWM controller
    g_phase_hr = DAB_PI_Ctrl.phase_cal;

    // Update phase to the output
    Phase_Output();
}
*/
/************************* Definition *************************
 * Function name: Phase_Output
 * Description: output phase to the HW
 * Variables:
 * - None
* Return: None
 **************************************************************/
#if(0)
void Phase_Output (void)
{
    float32_t phase_value;
    uint32_t  phase_int_val;
    uint32_t  phase_dec_val;

    phase_value = g_phase_hr;
    /****************************** NOTES ***********************************
    * BY CHECKING ON THE TEST BENCH, COMPARES HIGH SIDE VGS SIGNAL OF PRIMARY
    * AND HIGH SIDE VGS SIGNAL OF SECONDARY, THE PHASE IS CONDIGURED AS:
    * g_phase_hr = 53 --> ZERO DEGREE PHASE
    * g_phase_hr = 28 --> 90 DEGREE  PHASE (APPROX.)
    ************************************************************************/

    // Check Phase limit for DAB converter
    if (phase_value > PHASE_HIGH_LIMIT) phase_value = PHASE_HIGH_LIMIT;
    else if (phase_value < PHASE_LOW_LIMIT) phase_value = PHASE_LOW_LIMIT;


    phase_int_val = (uint32_t)phase_value;
    phase_dec_val = (uint32_t)((phase_value - (float32_t)phase_int_val)*MEP_STEP_PHASE);

    //phase_int_val = (uint32_t)(PHASE_OFFSET - phase_int_val);

    // Update phase
    //phase_pwm21_update_HR(PSFB_FB_PWM3_BASE);
    HWREG(PSFB_FB_PWM3_BASE + HRPWM_O_TBPHS) = ((uint32_t)((phase_int_val & 0xFFFF) << 8U) | (phase_dec_val & 0xFF)) << 8U;
}
#endif
/************************* Definition *************************
 * Function name: Phase_Output
 * Description: to ramp up the output voltage for soft start
 * Variables:
 * - None
* Return: None
 **************************************************************/
/*void SoftStart_RampUp_WihtoutPI (void)
{
    g_phase_hr = g_phase_hr + (float32_t)0.04;

    // Update phase to the output
    Phase_Output();
}*/
/************************* Definition *************************
 * Function name: Voltage_Calib
 * Description: is used to calibrate the voltage measurement
 * Variables:
 * - None
* Return: None
 **************************************************************/
#if (0)
void Voltage_Calib (void)
{
    DAB_PI_Ctrl.voltage_out_meas = (float32_t)adc_result_update_Out_Vol*DAB_Out_Voltage_Scale_Factor;

    // Print to tune the measurement
}
#endif
/************************* Definition *************************
 * Function name: SCI_Init
 * Description: is used to set UART to communicate with PC
 *              GPIO28 is SCI_A-RXD
 *              GPIO29 is SCI_A-TXD
 * Variables:
 * - baudrate: set baud rate of SCI (UART)
* Return: None
 **************************************************************/
void SCI_Init (uint32_t baudrate)
{
    //
    // GPIO28 is the SCI Rx pin.
    //
    GPIO_setMasterCore(DEVICE_GPIO_PIN_SCIRXDA, GPIO_CORE_CPU1);
    GPIO_setPinConfig(DEVICE_GPIO_CFG_SCIRXDA);
    GPIO_setDirectionMode(DEVICE_GPIO_PIN_SCIRXDA, GPIO_DIR_MODE_IN);
    GPIO_setPadConfig(DEVICE_GPIO_PIN_SCIRXDA, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(DEVICE_GPIO_PIN_SCIRXDA, GPIO_QUAL_ASYNC);

    //
    // GPIO29 is the SCI Tx pin.
    //
    GPIO_setMasterCore(DEVICE_GPIO_PIN_SCITXDA, GPIO_CORE_CPU1);
    GPIO_setPinConfig(DEVICE_GPIO_CFG_SCITXDA);
    GPIO_setDirectionMode(DEVICE_GPIO_PIN_SCITXDA, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(DEVICE_GPIO_PIN_SCITXDA, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(DEVICE_GPIO_PIN_SCITXDA, GPIO_QUAL_ASYNC);

    //
    // Initialize SCIA and its FIFO.
    //
    SCI_performSoftwareReset(SCIA_BASE);

    //
    // Configure SCIA for echoback.
    //
    SCI_setConfig(SCIA_BASE, DEVICE_LSPCLK_FREQ*2, baudrate, (SCI_CONFIG_WLEN_8 |
                                                        SCI_CONFIG_STOP_ONE |
                                                        SCI_CONFIG_PAR_NONE));
    SCI_resetChannels(SCIA_BASE);
    SCI_resetRxFIFO(SCIA_BASE);
    SCI_resetTxFIFO(SCIA_BASE);
    SCI_clearInterruptStatus(SCIA_BASE, SCI_INT_TXFF | SCI_INT_RXFF);
    SCI_enableFIFO(SCIA_BASE);
    SCI_enableModule(SCIA_BASE);
    SCI_performSoftwareReset(SCIA_BASE);
}

/************************* Definition *************************
 * Function name: DAB_HAL_setupDevice
 * Description: To initialize system clocks, peripheral clocks
 *              GPIO and to initialize Timer0's ISR
 * Variables:
 * - None
* Return: None
 **************************************************************/
void DAB_HAL_setupDevice(void)
{

    //
    // Initialize device clock and peripherals
    //
    Device_init();

    //
    // Disable pin locks and enable internal pull-ups.
    //
    Device_initGPIO();

    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();

    Interrupt_register(INT_TIMER0, &cpuTimer0ISR);

    CPUTimer_setPeriod(CPUTIMER0_BASE, 0xFFFFFFFF);

    // Initialize pre-scale counter to divide by 1 (SYSCLKOUT)
    CPUTimer_setPreScaler(CPUTIMER0_BASE , 0);

    // Make sure timer is stopped
    CPUTimer_stopTimer(CPUTIMER0_BASE);

    //
    // Reload all counter register with period value
    //
    CPUTimer_reloadTimerCounter(CPUTIMER0_BASE);
    //
    // TASK A FREQUENCY (100kHz)
    //
    CPUTimer_setPeriod(CPUTIMER0_BASE, (uint32_t)(DEVICE_SYSCLK_FREQ / TASKA_FREQ_HZ - 1));

    CPUTimer_stopTimer(CPUTIMER0_BASE);

    CPUTimer_reloadTimerCounter(CPUTIMER0_BASE);

    CPUTimer_setEmulationMode(CPUTIMER0_BASE,
                              CPUTIMER_EMULATIONMODE_STOPAFTERNEXTDECREMENT);
    CPUTimer_enableInterrupt(CPUTIMER0_BASE);

    CPUTimer_setEmulationMode(CPUTIMER0_BASE,
                                  CPUTIMER_EMULATIONMODE_STOPAFTERNEXTDECREMENT);

    Interrupt_enable(INT_TIMER0);

    CPUTimer_startTimer(CPUTIMER0_BASE);

}

/************************* Definition *************************
 * Function name: initCMPSS
 * Description: To configure the high comparator of CMPSS1
 * Variables:
 * - None
* Return: None
 **************************************************************/
void initCMPSS(uint32_t base)
{
    //
    // Enable CMPSS and configure the negative input signal to come from
    // the DAC
    //
    CMPSS_enableModule(base);
    CMPSS_configHighComparator(base, CMPSS_INSRC_DAC);
    CMPSS_configLowComparator(base, CMPSS_INSRC_DAC);

    //
    // Use VDDA as the reference for the DAC and set DAC value to midpoint for
    // arbitrary reference.
    //
    CMPSS_configDAC(base, CMPSS_DACREF_VDDA | CMPSS_DACVAL_SYSCLK |
                    CMPSS_DACSRC_SHDW);

    CMPSS_setHysteresis(base,4U);
    //Set DAC reference
    cmpss_dac_ref_high  = 4095U;
    cmpss_dac_ref_low   = 4095U;
    CMPSS_Ref_Set(base);
    //CMPSS_setDACValueHigh(base, 2048);

    // Configure digital filter. For this example, the maxiumum values will be
    // used for the clock prescale, sample window size, and threshold.
    CMPSS_configFilterHigh(base, 0U, 3U, 2U);
    CMPSS_configFilterLow(base, 0U, 3U, 2U);

    // Initialize the filter logic and start filtering
    //
    CMPSS_initFilterHigh(base);
    CMPSS_initFilterLow(base);

    //
    // Configure the output signals. Both CTRIPH and CTRIPOUTH will be fed by
    // the asynchronous comparator output.
    //
    //CMPSS_configOutputsHigh(base, CMPSS_TRIP_ASYNC_COMP);
    CMPSS_configOutputsHigh(base, CMPSS_TRIP_FILTER |
                                             CMPSS_TRIPOUT_FILTER);

    //
    // Configure the output signals. Both CTRIPL and CTRIPOUTL will be fed by
    // the asynchronous comparator output.
    //
    //CMPSS_configOutputsLow(base, CMPSS_TRIP_ASYNC_COMP |
    //                        CMPSS_TRIPOUT_ASYNC_COMP);
    CMPSS_configOutputsLow(base, CMPSS_TRIP_FILTER |
                                                 CMPSS_TRIPOUT_FILTER);
    //
    // Setup the Output X-BAR to output CTRIPOUTH on OUTPUTXBAR3
    //
    XBAR_setOutputMuxConfig(XBAR_OUTPUT3, XBAR_OUT_MUX04_CMPSS3_CTRIPOUTH);
    XBAR_enableOutputMux(XBAR_OUTPUT3, XBAR_MUX04);

    XBAR_setOutputMuxConfig(XBAR_OUTPUT4, XBAR_OUT_MUX05_CMPSS3_CTRIPOUTL);
    XBAR_enableOutputMux(XBAR_OUTPUT4, XBAR_MUX05);

    // Configure GPIO14 to output CTRIPOUT1H (routed through XBAROUTPUT3) and
    GPIO_setPinConfig(GPIO_14_OUTPUTXBAR3);
    // Configure GPIO15 to output CTRIPOUT1L (routed through XBAROUTPUT4) and
    GPIO_setPinConfig(GPIO_15_OUTPUTXBAR4);
}

/************************* Definition *************************
 * Function name: CMPSS_Ref_Set
 * Description: To set the reference for high and low CMPSS
 * Variables:
 * - None
* Return: None
 **************************************************************/
void CMPSS_Ref_Set (uint32_t base)
{
    HWREGH(base + CMPSS_O_DACHVALS) = cmpss_dac_ref_high;
    HWREGH(base + CMPSS_O_DACLVALS) = cmpss_dac_ref_low;
}

/************************* Definition *************************
 * Function name: Init_Ext_ISR
 * Description: To initialize external interrupts
 * Variables:
 * - None
* Return: None
 **************************************************************/
#if (0)
void Init_Ext_ISR (void)
{
    GPIO_setPinConfig(GPIO_26_GPIO26);
    GPIO_setDirectionMode(myGPIOInputInterrupt0, GPIO_DIR_MODE_IN);
    GPIO_setPadConfig(myGPIOInputInterrupt0, GPIO_PIN_TYPE_PULLUP);
    //GPIO_setMasterCore(myGPIOInputInterrupt0, GPIO_CORE_CPU1);
    GPIO_setQualificationMode(myGPIOInputInterrupt0, GPIO_QUAL_SYNC);

    GPIO_setInterruptType(GPIO_INT_XINT1, GPIO_INT_TYPE_FALLING_EDGE);
    GPIO_setInterruptPin(myGPIOInputInterrupt0, GPIO_INT_XINT1);
    GPIO_enableInterrupt(GPIO_INT_XINT1);

    Interrupt_register(INT_XINT1, &gpioInterruptHandler1);
    Interrupt_enable(INT_XINT1);
}
#endif
