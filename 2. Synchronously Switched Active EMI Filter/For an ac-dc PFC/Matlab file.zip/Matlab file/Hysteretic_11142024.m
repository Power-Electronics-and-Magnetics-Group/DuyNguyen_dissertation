% This is for hysteretic control. No sweep
clc
clear

format long
%yellow_color = '#e2d810';
yellow_color = '#CbC000';
red_color = '#ff0000'; %'#d9138a';
blue_color = '#0000ff';%'#12a4d9';
black_color = '#322e2f';
magenta_color = '#d9138a';
cyan_color = '#12a4d9';

%% Design control loop for PFC boost converter - Average current control mode

%Converter information
Vac_rms=110; % Need to consider Vg_max, Vg_min
Vac_pk=Vac_rms*2^0.5;
fline=60;
Tline=1/fline;
wline=2*pi*fline;
T0=Tline/2;f0=1/T0;
w0=2*wline;
Pout=300;
Pav=Pout;
Vout=400;
fsw=150e3; Tsw=1/fsw;
wsw=2*pi*fsw;


Re=Vac_rms^2/Pav; % Equivalent input impedance at the source
Lf=6.2e-6;
Resr=0.1;
Cf=5e-6;   % Capacitor of AEF

C=500e-6;
L=240e-6; 
R=0.28;
Q_i = [1000 800 600 300]; % quality of the boost inductor
Ro_i = wsw*L./Q_i; % Parasitic resistor of boost circuit

%Rf_i=linspace(0,1,50);
RR=1;
Gain_H=(1+RR);
Gain_L=(1-RR);

Vg=Vout*(Lf/L);

%[Ro_m,Rf_m] = meshgrid(Ro_i,Rf_i);

Order_of_harmonics = 10;
%attenuation_1st_Ai = zeros(numel(Rf_i),numel(Ro_i));
%attenuation_2nd_Ai = zeros(numel(Rf_i),numel(Ro_i));
%attenuation_3rd_Ai = zeros(numel(Rf_i),numel(Ro_i));
%attenuation_4th_Ai = zeros(numel(Rf_i),numel(Ro_i));
%attenuation_5th_Ai = zeros(numel(Rf_i),numel(Ro_i));

Tswmax=(Gain_H-Gain_L)*L/Re + (Gain_H-Gain_L)*Vac_pk*L/((Vout-Vac_pk)*Re);
fswmin=1/Tswmax;
Cmin=ceil(1/(4*pi^2*fswmin^2*Lf)*1e6)/1e6 + 1e-6;
if (Cmin <= 1e-6)
    Cmin=1e-6;
end

syms x

            w0res=1/(Lf*Cf)^0.5;
            %w0res=(4*Lf*Cf-Resr^2*Cf^2)^0.5/(2*Lf*Cf);
            T0res=2*pi/w0res;
            lamda=-Resr/(2*Lf);
            %damping_factor = -lamda/w0res;
            %wd=w0res*(1-damping_factor^2)^0.5;
    
            tx=(atan(-wline*Cf*Re)+pi)/wline;
            k1=Vac_pk*sin(wline*tx);
            
            ty = vpasolve(k1*exp(-(x-tx)/(Re*Cf)) == -Vac_pk*sin(wline*x),x);
            if (ty > 2*T0) 
                t0=0;
            else
                t0=double(ty-Tline/2);
            end 
            t1=double(tx);
            t_total=double(t0+(Tline/2-tx));
        
            Tsample = 0.5e-8;    % 10ns sampling time
            cdf=ceil((t1-t0)/Tsample);
            torigin=0; status = 1;
            g_cnt=0;
            nsample_total = ceil(T0/Tsample);
            %iL_boost = zeros(1, nsample_total);
            %iL_aef = zeros(1, nsample_total);
            %time = zeros(1, nsample_total);
%%    
        while  torigin <= T0
            if (torigin <= cdf*Tsample)
                    Vrec1=Vac_pk*abs(sin(wline*(torigin+t0))); % [ t0, t1]
                    iL_aef_avg1=wline*Cf*Vac_pk*cos(wline*(torigin+t0));
                    Iboost_avg1=Vrec1/Re;
                    %if (status == 1)
                        ton=(Gain_H-Gain_L)*L/(Re-Gain_H*wline*L*cot(wline*(torigin+t0)));
                        xyz_on=ceil(ton/Tsample);
                        ton=xyz_on*Tsample;
                    %else
                        Vrec2=Vac_pk*abs(sin(wline*(torigin+t0+ton))); % [ t0, t1]
                        iL_aef_avg2=wline*Cf*Vac_pk*cos(wline*(torigin+t0+ton));
                        Iboost_avg2=Vrec2/Re;
                        toff=((Gain_H-Gain_L)*L*Vrec2)/((Vout-Vrec2)*Re+Gain_L*Vac_pk*wline*L*cos(wline*(torigin+t0+ton)));
                        xyz_off=ceil(toff/Tsample);
                        toff=xyz_off*Tsample;  
                    %end
            else
                    Vrec1=k1*exp(-(torigin-cdf*Tsample)/(Re*Cf)); % [t1,T0] and [T0,T0+t0]
                    iL_aef_avg1=(-k1/Re)*exp(-(torigin-cdf*Tsample)/(Re*Cf));
                    Iboost_avg1=Vrec1/Re;
                    %if (status == 1)
                        ton=(Gain_H-Gain_L)/(Re/L+Gain_H/(Re*C));
                        xyz_on=ceil(ton/Tsample);
                        ton=xyz_on*Tsample;
                    %else
                        Vrec2=k1*exp(-(torigin-cdf*Tsample+ton)/(Re*Cf)); % [t1,T0] and [T0,T0+t0]
                        iL_aef_avg2=(-k1/Re)*exp(-(torigin-cdf*Tsample+ton)/(Re*Cf));
                        Iboost_avg2=Vrec2/Re;
                        toff=((Gain_H-Gain_L))/((Vout/Vrec2-1)*(Re/L)-Gain_L/(Re*C));
                        xyz_off=ceil(toff/Tsample);
                        toff=xyz_off*Tsample;
                    %end
            end
%%
            torigin = torigin+(ton+toff);
            % For boost converter
            Iboost_min=(Iboost_avg1-Vrec1/(2*L)*(ton));
            Iboost_max=(Iboost_avg2+(Vout-Vrec2)/(2*L)*(toff));
            
            % For the AEF
            delta_I_conv1=(Vrec1/L)*(ton); % Imax-Imin in one switching cycle
            delta_I_conv2=((Vout-Vrec2)/L)*(toff); 
            Iaef_max1 = delta_I_conv1/2 + iL_aef_avg1;
            Iaef_min1 = -delta_I_conv1/2 + iL_aef_avg1;
            Iaef_max2 = delta_I_conv2/2 + iL_aef_avg2;
            Iaef_min2 = -delta_I_conv2/2 + iL_aef_avg2;

            xx=exp(lamda*ton)*cos(w0res*ton);
            yy=exp(lamda*ton)*sin(w0res*ton);
            zz=exp(lamda*(toff))*cos(w0res*(toff));
            tt=exp(lamda*(toff))*sin(w0res*(toff));
            A1=Iaef_max1;
            A2=(Iaef_min1-Iaef_max1*xx)/yy;
            A3=Iaef_min2;
            A4=(Iaef_max2-Iaef_min2*zz)/tt;

            for m=1:(xyz_on+xyz_off-1)
                g_cnt = g_cnt + 1;
                if (m < xyz_on)  
                    iL_boost(g_cnt)= (Iboost_min*exp(-R*(m-1)*Tsample/L) + ((Vrec1)/R)*(1-exp(-R*(m-1)*Tsample/L)));
                    %Imaxx=iL_boost(g_cnt);
                else              
                    iL_boost(g_cnt)= (Iboost_max*exp(-R*((m-1)*Tsample-ton)/L) + ((Vrec2-Vout)/R)*(1-exp(-R*((m-1)*Tsample-ton)/L)));
                end
    
                if (m < xyz_on)
                    iL_aef(g_cnt)=exp(lamda*(m-1)*Tsample)*(A1*cos(w0res*(m-1)*Tsample)+A2*sin(w0res*(m-1)*Tsample));
                else
                    iL_aef(g_cnt)=exp(lamda*((m-1)*Tsample-ton))*(A3*cos(w0res*((m-1)*Tsample-ton))+A4*sin(w0res*((m-1)*Tsample-ton)));
                end
                time(g_cnt)=(g_cnt-1)*Tsample;
            end
        end
        
        isum=iL_boost+iL_aef;
        No_cycles_120Hz=3;
        times_total = zeros(No_cycles_120Hz,numel(time));
        iL_boost_total = zeros(No_cycles_120Hz,numel(time));
        iL_aef_total = zeros(No_cycles_120Hz,numel(time));
        isum_total = zeros(No_cycles_120Hz,numel(time));
        for n_cycles_=1:No_cycles_120Hz
            times_total(n_cycles_,:)=(n_cycles_-1)*T0+time;
            iL_boost_total(n_cycles_,:)=iL_boost;
            iL_aef_total(n_cycles_,:)=iL_aef;
            isum_total(n_cycles_,:)=isum;
        end

        times_total=reshape(times_total.',1,[]);
        iL_boost_total=reshape(iL_boost_total.',1,[]);
        iL_aef_total=reshape(iL_aef_total.',1,[]);
        isum_total=reshape(isum_total.',1,[]);

        ddTsample = mean(diff(times_total)); % sampling interval
        Fs = 1/ddTsample;
        Fn = Fs/2;
        N = length(times_total);
        fft_isum = fft(isum_total)/N;
        fft_i_boost = fft(iL_boost_total)/N;
        Fv = linspace(0, 1, fix(N/2)+1)*Fn;                 % Frequency Vector
        Iv = 1:length(Fv);   
        fft_i_sum_mag=mag2db(abs(fft_isum(Iv)));
        fft_i_boost_mag=mag2db(abs(fft_i_boost(Iv)));
        fft_Ai_dB=fft_i_sum_mag-fft_i_boost_mag;
        f0_fft_start=40e3;   
        source_Ai = max(fft_i_sum_mag(Fv>20000));
        ffffff=find(fft_i_sum_mag== source_Ai);
        source_Ai = max(fft_i_sum_mag(ffffff-2:ffffff+2));
        boost_Ai  = max(fft_i_boost_mag(ffffff-2:ffffff+2));
        attenuation_Ai = (source_Ai-boost_Ai);

%%
if (1)
figure();
plot(times_total,iL_boost_total);
figure();
plot(times_total,isum_total);
figure();
plot(times_total,iL_aef_total);
figure();
plot(Fv,fft_i_boost_mag);
xlim([5e4 5e5])
figure();
plot(Fv,fft_i_sum_mag);
xlim([5e4 5e5])
end