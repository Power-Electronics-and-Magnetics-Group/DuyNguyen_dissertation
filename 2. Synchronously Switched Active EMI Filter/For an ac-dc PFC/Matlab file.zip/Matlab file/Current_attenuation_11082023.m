% Use to run with single R and Cf. It works but the analysis is not
% accurate 11/12/2023
clc
clear

format long
%yellow_color = '#e2d810';
yellow_color = '#CbC000';
red_color = '#ff0000'; %'#d9138a';
blue_color = '#0000ff';%'#12a4d9';
black_color = '#322e2f';

magenta_color = '#d9138a';
cyan_color = '#12a4d9';

%% Design control loop for PFC boost converter - Average current control mode

%Converter information
Vac_rms=110; % Need to consider Vg_max, Vg_min
Vac_pk=Vac_rms*2^0.5;
fline=60;
Tline=1/fline;
wline=2*pi*fline;
T0=Tline/2;f0=1/T0;
w0=2*wline;
Pout=300;
Pav=Pout;
Vout=400;
fsw=150e3; Tsw=1/fsw;
wsw=2*pi*fsw;


Re=Vac_rms^2/Pav; % Equivalent input impedance at the source
Lf=6.2e-6;
Resr=0.2;
Cf=10e-6;
c_length=length(Cf);
w0res=1/(Lf*Cf)^0.5;
T0res=2*pi/w0res;
tplus=Tsw/2;

C=500e-6;
L=240e-6; 
R=0.28;
Vg=Vout*(Lf/L);

syms x
for k=1:c_length
    tx=(atan(-wline*Cf(k)*Re)+pi)/wline;
    k1=Vac_pk*sin(wline*tx);
    
    ty = vpasolve(k1*exp(-(x-tx)/(Re*Cf(k))) == -Vac_pk*sin(wline*x),x);
    if (ty > 2*T0) 
        t0=0;
    else
        t0=double(ty-Tline/2);
    end 
    t1=double(tx);
    t_total=double(t0+(Tline/2-tx));

    No_cycles_Tsw=fsw/f0;
   
    sample_per_Tsw = 1000;
    t=linspace(0,Tsw,sample_per_Tsw);
    
    iL_boost = zeros(No_cycles_Tsw, sample_per_Tsw);
    iL_aef = zeros(No_cycles_Tsw, sample_per_Tsw);
    %iL_aef_avg = zeros(No_cycles_Tsw, sample_per_Tsw);
    time = zeros(No_cycles_Tsw, sample_per_Tsw);
    %vaa=[];
    for n_cycles=1:No_cycles_Tsw
        if (((n_cycles-1)*Tsw + Tsw/2) <= (t1-t0))
            Vrec=Vac_pk*abs(sin(wline*((n_cycles-1)*Tsw+Tsw/2+t0))); % [ t0, t1]
            iL_aef_avg=wline*Cf(k)*Vac_pk*cos(wline*((n_cycles-1)*Tsw+Tsw/2+t0));
            %vaa=[vaa Vrec];
        else
            Vrec=k1*exp(-((n_cycles-1)*Tsw+Tsw/2-t1+t0)/(Re*Cf(k))); % [t1,T0] and [T0,T0+t0]
            iL_aef_avg=(-k1/Re)*exp(-((n_cycles-1)*Tsw+Tsw/2-t1+t0)/(Re*Cf(k)));
            %vaa=[vaa Vrec];
        end
        % For boost converter
        Iboost_avg=Vrec/Re;
        duty_cycle_avg=(1-Vrec/Vout);
        Iboost_min=(Iboost_avg-Vrec/(2*L)*(duty_cycle_avg*Tsw));
        Iboost_max=(Iboost_avg+(Vrec)/(2*L)*(duty_cycle_avg*Tsw));
        
        % For the AEF
        delta_I_conv=(Vrec/L)*(duty_cycle_avg*Tsw); % Imax-Imin in one switching cycle
        Iaef_max = delta_I_conv/2 + iL_aef_avg;
        Iaef_min = -delta_I_conv/2 + iL_aef_avg;
        lamda=-Resr/(2*Lf);
        xx=exp(lamda*duty_cycle_avg*Tsw)*cos(w0res*duty_cycle_avg*Tsw);
        yy=exp(lamda*duty_cycle_avg*Tsw)*sin(w0res*duty_cycle_avg*Tsw);
        zz=exp(lamda*(1-duty_cycle_avg)*Tsw)*cos(w0res*(1-duty_cycle_avg)*Tsw);
        tt=exp(lamda*(1-duty_cycle_avg)*Tsw)*sin(w0res*(1-duty_cycle_avg)*Tsw);
        A1=Iaef_max;
        A2=(Iaef_min-Iaef_max*xx)/yy;
        A3=Iaef_min;
        A4=(Iaef_max-Iaef_min*zz)/tt;

        for m=1:(numel(t))
            if (mod(t(m),Tsw) <= duty_cycle_avg*Tsw)  
                %iL_boost=[iL_boost (Imin*exp(-R*mod(t(m),Tsw)/L) + ((Vrec)/R)*(1-exp(-R*mod(t(m),Tsw)/L)))];
                iL_boost(n_cycles,m)= (Iboost_min*exp(-R*mod(t(m),Tsw)/L) + ((Vrec)/R)*(1-exp(-R*mod(t(m),Tsw)/L)));
                %Imaxx=iL_boost(n_cycles,m);
            elseif ((mod(t(m),Tsw) > duty_cycle_avg*Tsw) && (mod(t(m),Tsw) <= (Tsw)))                
                %iL_boost=[iL_boost (Imax*exp(-R*(mod(t(m),Tsw)-duty_cycle_avg*Tsw)/L) + ((Vrec-Vout)/R)*(1-exp(-R*(mod(t(m),Tsw)-duty_cycle_avg*Tsw)/L)))];
                iL_boost(n_cycles,m)= (Iboost_max*exp(-R*(mod(t(m),Tsw)-duty_cycle_avg*Tsw)/L) + ((Vrec-Vout)/R)*(1-exp(-R*(mod(t(m),Tsw)-duty_cycle_avg*Tsw)/L)));
            end

            if (mod(t(m),Tsw) <= duty_cycle_avg*Tsw)
                iL_aef(n_cycles,m)=exp(lamda*mod(t(m),Tsw))*(A1*cos(w0res*mod(t(m),Tsw))+A2*sin(w0res*mod(t(m),Tsw)));
            elseif ((mod(t(m),Tsw) > duty_cycle_avg*Tsw) && (mod(t(m),Tsw) <= (Tsw)))
                iL_aef(n_cycles,m)=exp(lamda*(mod(t(m),Tsw)-duty_cycle_avg*Tsw))*(A3*cos(w0res*(mod(t(m),Tsw)-duty_cycle_avg*Tsw))+A4*sin(w0res*(mod(t(m),Tsw)-duty_cycle_avg*Tsw)));
            end
            time(n_cycles,m)=(n_cycles-1)*Tsw+t(m);
        end
        %time=[time ((n_cycles-1)*Tsw+t(1:end))];
    end
end %for k=1:c_length

%%
    iL_boost=iL_boost-Iboost_avg;
    %iL_aef=iL_aef-iL_aef_avg;
    isum=iL_boost+iL_aef;
    time=reshape(time.',1,[]);
    iL_boost=reshape(iL_boost.',1,[]);
    iL_aef=reshape(iL_aef.',1,[]);
    isum=reshape(isum.',1,[]);
    
    No_cycles_120Hz=1;
    times_total = zeros(No_cycles_120Hz,numel(time));
    iL_boost_total = zeros(No_cycles_120Hz,numel(time));
    iL_aef_total = zeros(No_cycles_120Hz,numel(time));
    isum_total = zeros(No_cycles_120Hz,numel(time));
    for n_cycles_=1:No_cycles_120Hz
        times_total(n_cycles_,:)=(n_cycles_-1)*T0+time;
        iL_boost_total(n_cycles_,:)=iL_boost;
        iL_aef_total(n_cycles_,:)=iL_aef;
        isum_total(n_cycles_,:)=isum;
    end
%%
    times_total=reshape(times_total.',1,[]);
    iL_boost_total=reshape(iL_boost_total.',1,[]);
    iL_aef_total=reshape(iL_aef_total.',1,[]);
    isum_total=reshape(isum_total.',1,[]);
    

    Tsample = mean(diff(times_total)); % sampling interval
    Fs = 1/Tsample;
    Fn = Fs/2;
    N = length(times_total);
    fft_isum = fft(isum_total)/N;
    fft_i_boost = fft(iL_boost_total)/N;
    Fv = linspace(0, 1, fix(N/2)+1)*Fn;                 % Frequency Vector
    Iv = 1:length(Fv);   
    fft_i_sum_mag=mag2db(abs(fft_isum(Iv)));
    fft_i_boost_mag=mag2db(abs(fft_i_boost(Iv)));
    fft_Ai_dB=fft_i_sum_mag-fft_i_boost_mag;

    Order_of_harmonics = 10;
    attenuation_Ai = zeros(c_length,Order_of_harmonics);
    for i_order=1:Order_of_harmonics
        xs=fft_Ai_dB(Fv>=(fsw*i_order-2) & Fv<=(fsw*i_order+2));
        attenuation_Ai(1,i_order) = min(xs);
    end
   
    figure();
    %stem(Fv,fft_i_sum_mag-fft_i_boost_mag);
    plot(Fv,fft_Ai_dB);
    xlim([1e5 2e6])

    figure();
    plot(times_total,iL_boost_total);
    figure();
    plot(times_total,iL_aef_total);
    figure();
    plot(times_total,isum_total);
