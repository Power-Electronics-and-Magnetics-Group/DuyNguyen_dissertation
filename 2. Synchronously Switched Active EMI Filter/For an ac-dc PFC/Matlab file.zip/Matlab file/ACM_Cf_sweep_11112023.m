% Use to sweep R and Cf. It works but the analysis is not
% accurate 11/12/2023
clc
clear

format long
%yellow_color = '#e2d810';
red_color = '#ff0000'; %'#d9138a';
blue_color = '#0000ff';%'#12a4d9';

yellow_color = '#CbC000';
black_color = '#322e2f';
magenta_color = '#d9138a';
cyan_color = '#12a4d9';
orange_color = '#D95319';

%% Design control loop for PFC boost converter - Average current control mode

%Converter information
Vac_rms=110; % Need to consider Vg_max, Vg_min
Vac_pk=Vac_rms*2^0.5;
fline=60;
Tline=1/fline;
wline=2*pi*fline;
T0=Tline/2;f0=1/T0;
w0=2*wline;
Pout=300;
Pav=Pout;
Vout=400;
fsw=150e3; Tsw=1/fsw;
wsw=2*pi*fsw;


Re=Vac_rms^2/Pav; % Equivalent input impedance at the source
Lf=6.2e-6;
Resr=0.05;
%Cf_i = 1e-6:0.5e-6:30e-6;   % Capacitor of AEF
Cf_i = linspace(1e-6,30e-6,40);   % Capacitor of AEF

C=500e-6;
L=240e-6; 
%R=0.05;
%Q_i = [1000 800 600 300]; % quality of the boost inductor
Q_i = [600 400 200 100]; % quality of the boost inductor
R_i = wsw*L./Q_i; % Parasitic resistor of boost circuit

Vg=Vout*(Lf/L);

[Ro_m, Cf_m] = meshgrid(R_i,Cf_i);

Order_of_harmonics = 10;
attenuation_1st_Ai = zeros(numel(Cf_i),numel(R_i));
attenuation_2nd_Ai = zeros(numel(Cf_i),numel(R_i));
%attenuation_3rd_Ai = zeros(numel(Cf_i),numel(R_i));
%attenuation_4th_Ai = zeros(numel(Cf_i),numel(R_i));
%attenuation_5th_Ai = zeros(numel(Cf_i),numel(R_i));

syms x

for k=1:numel(Cf_i)
    for n=1:numel(R_i)
        R = Ro_m(k,n);
        Cf=Cf_m(k,n);
        w0res=1/(Lf*Cf)^0.5;
        T0res=2*pi/w0res;
        lamda=-Resr/(2*Lf);
        damping_factor = -lamda/w0res;
        wd=w0res*(1-damping_factor^2)^0.5;

        tx=(atan(-wline*Cf*Re)+pi)/wline;
        k1=Vac_pk*sin(wline*tx);
        
        ty = vpasolve(k1*exp(-(x-tx)/(Re*Cf)) == -Vac_pk*sin(wline*x),x);
        if (ty > 2*T0) 
            t0=0;
        else
            t0=double(ty-Tline/2);
        end 
        t1=double(tx);
        t_total=double(t0+(Tline/2-tx));
    
        No_cycles_Tsw=fsw/f0;
       
        sample_per_Tsw = 2000;
        t=linspace(0,Tsw,sample_per_Tsw);
        Tsample = mean(diff(t));
        
        iL_boost = zeros(No_cycles_Tsw, sample_per_Tsw-1);
        iL_aef = zeros(No_cycles_Tsw, sample_per_Tsw-1);
        %iL_aef_avg = zeros(No_cycles_Tsw, sample_per_Tsw);
        time = zeros(No_cycles_Tsw, sample_per_Tsw-1);
        %vaa=[];
        for n_cycles=1:No_cycles_Tsw
            cdf=ceil((-Tsw/2+t1-t0)/Tsw);
             if ((n_cycles-1)*Tsw <= cdf*Tsw)
                Vrec=Vac_pk*abs(sin(wline*((n_cycles-1)*Tsw+Tsw/2+t0))); % [ t0, t1]
                iL_aef_avg=wline*Cf*Vac_pk*cos(wline*((n_cycles-1)*Tsw+Tsw/2+t0));
                %vaa=[vaa Vrec];
            else
                Vrec=k1*exp(-((n_cycles-1)*Tsw-cdf*Tsw)/(Re*Cf)); % [t1,T0] and [T0,T0+t0]
                iL_aef_avg=(-k1/Re)*exp(-((n_cycles-1)*Tsw-cdf*Tsw)/(Re*Cf));
                %vaa=[vaa Vrec];
            end
            % For boost converter
            Iboost_avg=Vrec/Re;
            duty_cycle_avg=(1-Vrec/Vout);
            abc=duty_cycle_avg*Tsw/Tsample;
            nTsample=ceil(abc); % round up

            Iboost_min=(Iboost_avg-Vrec/(2*L)*(nTsample*Tsample));
            Iboost_max=(Iboost_avg+(Vrec)/(2*L)*(nTsample*Tsample));
            
            % For the AEF
            delta_I_conv=(Vrec/L)*(nTsample*Tsample); % Imax-Imin in one switching cycle
            Iaef_max = delta_I_conv/2 + iL_aef_avg;
            Iaef_min = -delta_I_conv/2 + iL_aef_avg;
            
            xx=exp(lamda*nTsample*Tsample)*cos(w0res*nTsample*Tsample);
            yy=exp(lamda*nTsample*Tsample)*sin(w0res*nTsample*Tsample);
            zz=exp(lamda*(Tsw-nTsample*Tsample))*cos(w0res*(Tsw-nTsample*Tsample));
            tt=exp(lamda*(Tsw-nTsample*Tsample))*sin(w0res*(Tsw-nTsample*Tsample));
            A1=Iaef_max;
            A2=(Iaef_min-Iaef_max*xx)/yy;
            A3=Iaef_min;
            A4=(Iaef_max-Iaef_min*zz)/tt;
    
            for m=1:(numel(t))
                if (mod(t(m),Tsw) <= nTsample*Tsample)  
                    %iL_boost=[iL_boost (Imin*exp(-R*mod(t(m),Tsw)/L) + ((Vrec)/R)*(1-exp(-R*mod(t(m),Tsw)/L)))];
                    iL_boost(n_cycles,m)= (Iboost_min*exp(-R*mod(t(m),Tsw)/L) + ((Vrec)/R)*(1-exp(-R*mod(t(m),Tsw)/L)))-Iboost_avg;
                    %Imaxx=iL_boost(n_cycles,m);
                elseif ((mod(t(m),Tsw) > nTsample*Tsample) && (mod(t(m),Tsw) <= (Tsw)))              
                    %iL_boost=[iL_boost (Imax*exp(-R*(mod(t(m),Tsw)-duty_cycle_avg*Tsw)/L) + ((Vrec-Vout)/R)*(1-exp(-R*(mod(t(m),Tsw)-duty_cycle_avg*Tsw)/L)))];
                    iL_boost(n_cycles,m)= (Iboost_max*exp(-R*(mod(t(m),Tsw)-nTsample*Tsample)/L) + ((Vrec-Vout)/R)*(1-exp(-R*(mod(t(m),Tsw)-nTsample*Tsample)/L)))-Iboost_avg;
                end
    
                if (mod(t(m),Tsw) <= nTsample*Tsample)
                    iL_aef(n_cycles,m)=exp(lamda*mod(t(m),Tsw))*(A1*cos(w0res*mod(t(m),Tsw))+A2*sin(w0res*mod(t(m),Tsw)))-iL_aef_avg;
                elseif ((mod(t(m),Tsw) > nTsample*Tsample) && (mod(t(m),Tsw) <= (Tsw)))
                    iL_aef(n_cycles,m)=exp(lamda*(mod(t(m),Tsw)-nTsample*Tsample))*(A3*cos(w0res*(mod(t(m),Tsw)-nTsample*Tsample))+A4*sin(w0res*(mod(t(m),Tsw)-nTsample*Tsample)))-iL_aef_avg;
                end
                time(n_cycles,m)=(n_cycles-1)*Tsw+t(m);
            end
        end %for n_cycles=1:No_cycles_Tsw

    %iL_boost=iL_boost-Iboost_avg;
    isum=iL_boost+iL_aef;
    time=reshape(time.',1,[]);
    iL_boost=reshape(iL_boost.',1,[]);
    iL_aef=reshape(iL_aef.',1,[]);
    isum=reshape(isum.',1,[]);

    Tsample = mean(diff(time)); % sampling interval
    Fs = 1/Tsample;
    Fn = Fs/2;
    N = length(time);
    fft_isum = fft(isum)/N;
    fft_i_boost = fft(iL_boost)/N;
    Fv = linspace(0, 1, fix(N/2)+1)*Fn;                 % Frequency Vector
    Iv = 1:length(Fv);   
    fft_i_sum_mag=mag2db(abs(fft_isum(Iv)));
    fft_i_boost_mag=mag2db(abs(fft_i_boost(Iv)));
    fft_Ai_dB=fft_i_sum_mag-fft_i_boost_mag;
       
    attenuation_1st_Ai(k,n)=min(fft_Ai_dB(Fv>=(fsw*1-2) & Fv<=(fsw*1+2)));
    attenuation_2nd_Ai(k,n)=min(fft_Ai_dB(Fv>=(fsw*2-1) & Fv<=(fsw*2+1)));
    %attenuation_3rd_Ai(k,n)=min(fft_Ai_dB(Fv>=(fsw*3-5e3) & Fv<=(fsw*3+5e3)));
    %attenuation_4th_Ai(k,n)=min(fft_Ai_dB(Fv>=(fsw*4-5e3) & Fv<=(fsw*4+5e3)));
    %attenuation_5th_Ai(k,n)=min(fft_Ai_dB(Fv>=(fsw*5-5e3) & Fv<=(fsw*5+5e3)));
    end
end %for k=1:numel(Cf_i)


%%
% This THD range is calculated for harmonics up to 20 and C is varied from 1uF to 30uF, 20 steps
THD=100*[0.000220533844843666
0.00109137337429496
0.00220892068663433
0.00370053671466192
0.00555005770140729
0.00773794382820935
0.0102418017005475
0.0130369733306691
0.0160971725467425
0.0193951481377325
0.0229033520499286
0.0265945906354089
0.0304426373577501
0.0344227865213127
0.0385123295323409
0.0426909379317231
0.0469409409439237
0.0512474895095055
0.0555986036021601
0.0599851049009732
0.0644004423453211
0.0688404234204505
0.0733028688266604
0.0777872120710605
0.0822940681108203
0.0868247961766990
0.0913810811600427
0.0959645554780116
0.100576479353839
0.105217492344841
0.109887443223165
0.114585299512545
0.119309132628430
0.124056170082202
0.128822902875885
0.133605234158619
0.138398654421240
0.143198428835229
0.147999783584787
0.152798079946771];

Harmonics_3rd=1000*[0.000283811376149889
0.00140979898518920
0.00286739549735055
0.00483527923107711
0.00731159224215930
0.0102940032579373
0.0137797144310142
0.0177654694008041
0.0222475626159451
0.0272218498637297
0.0326837599463520
0.0386283074379855
0.0450501064515409
0.0519433853394398
0.0593020022489105
0.0671194614491848
0.0753889303455597
0.0841032570935803
0.0932549887256074
0.102836389701721
0.112839460797275
0.123255958240409
0.134077413014425
0.145295150242104
0.156900308571686
0.168883859487410
0.181236626471028
0.193949303944651
0.207012475929474
0.220416634359428
0.234152196993428
0.248209524874743
0.262578939290877
0.277250738192306
0.292215212033377
0.307462659003537
0.322983399621904
0.338767790672889
0.354806238465101
0.371089211400159];

%%
figure();
%yyaxis left
plot(Cf_i*1e6,(abs(attenuation_1st_Ai(:,1))),'Color' , cyan_color,'LineWidth',5);
hold on
plot(Cf_i*1e6,(abs(attenuation_1st_Ai(:,2))),'Color' , magenta_color,'LineWidth',5);
plot(Cf_i*1e6,(abs(attenuation_1st_Ai(:,3))),'Color' , yellow_color,'LineWidth',5);
plot(Cf_i*1e6,(abs(attenuation_1st_Ai(:,4))),'Color' , black_color,'LineWidth',5);
C=linspace(1e-6,30e-6,40);
%xlim([0 100]);
ylim([15 39]);
set(gca,'FontSize',16)
%label_x=xlabel('$Capacitance \ C \ [uF]$','Interpreter','latex','FontSize',18,'HorizontalAlignment','center');
label_x=xlabel('$Capacitance \ C_f \ [\mu F]$','Interpreter','latex','FontSize',22,'HorizontalAlignment','center');
%xlabel('\it{Capacitance C} [\it{\muF}]','FontSize',18,'HorizontalAlignment','center');
set(label_x,'rotation',0);
label_h=ylabel('$A_{1i} \ [dB]$','Interpreter','latex','FontSize',22,'HorizontalAlignment','center');
set(label_h,'rotation',90);
yyaxis right
plot(C.*1e6,THD,'--','Color', orange_color,'LineWidth',5.5);
ax = gca;
ax.YAxis(1).Color = 'k';
ax.YAxis(2).Color = 'k';
hold off
%legend('\it{Q_L}=1000','\it{Q_L}=800','\it{Q_L}=600','\it{Q_L}=300','\it{THD}','Orientation','horizontal','Location','southeast','FontSize',20);
legend('$Q_L=800$','$Q_L=600$','$Q_L=400$','$Q_L=200$','$THD$','Interpreter','latex','Orientation','horizontal','Location','southeast','FontSize',19)
legend('boxoff')
My_LGD = legend;
My_LGD.NumColumns = 2;    % Show legends in 5 lines
label_h=ylabel('$THD \ [\%]$','Interpreter','latex','FontSize',22,'HorizontalAlignment','center');
set(label_h,'rotation',90);
h=gcf;
set(h,'Position',[200 200 720 570]);
%grid on
grid minor

if (0)
for i=2:length(Cf_i)
    delta_C(i-1)=Cf_i(i)-Cf_i(i-1);
    delta_attenuation_1st_Ai(i-1,1)=attenuation_1st_Ai(i,1)-attenuation_1st_Ai(i-1,1);
    delta_attenuation_1st_Ai(i-1,2)=attenuation_1st_Ai(i,2)-attenuation_1st_Ai(i-1,2);
end
xxx=linspace(1,39,39);
figure();
plot(xxx,delta_attenuation_1st_Ai(:,1),'Color' , blue_color,'LineWidth',2.8);
hold on
plot(xxx,delta_attenuation_1st_Ai(:,2),'Color' , red_color,'LineWidth',2.8);
end

if (0)
figure();
plot(Cf_i*1e6,abs(attenuation_1st_Ai(:,1))./THD,'Color' , blue_color,'LineWidth',2.8);
hold on
plot(Cf_i*1e6,abs(attenuation_1st_Ai(:,2))./THD,'Color' , yellow_color,'LineWidth',2.8);
plot(Cf_i*1e6,abs(attenuation_1st_Ai(:,3))./THD,'Color' , red_color,'LineWidth',2.8);
plot(Cf_i*1e6,abs(attenuation_1st_Ai(:,4))./THD,'Color' , black_color,'LineWidth',2.8);
%xlim([0 100]);
%ylim([20 47]);
set(gca,'FontSize',16)
label_x=xlabel('$Capacitance \ C \ [uF]$','Interpreter','latex','FontSize',18,'HorizontalAlignment','center');
%xlabel('\it{Capacitance C} [\it{\muF}]','FontSize',18,'HorizontalAlignment','center');
set(label_x,'rotation',0);
label_h=ylabel('$\frac{A_{1i}}{THD} \ [dB]$','Interpreter','latex','FontSize',22,'HorizontalAlignment','center');
set(label_h,'rotation',90);
legend('\it{Q_L}=1000','\it{Q_L}=800','\it{Q_L}=600','\it{Q_L}=300','Orientation','horizontal','Location','southeast','FontSize',20);
legend('boxoff')
h=gcf;
set(h,'Position',[200 200 760 580]);
grid on
grid minor

figure();
plot(Cf_i*1e6,abs(attenuation_1st_Ai(:,1))./Harmonics_3rd,'Color' , blue_color,'LineWidth',2.8);
hold on
plot(Cf_i*1e6,abs(attenuation_1st_Ai(:,2))./Harmonics_3rd,'Color' , yellow_color,'LineWidth',2.8);
plot(Cf_i*1e6,abs(attenuation_1st_Ai(:,3))./Harmonics_3rd,'Color' , red_color,'LineWidth',2.8);
plot(Cf_i*1e6,abs(attenuation_1st_Ai(:,4))./Harmonics_3rd,'Color' , black_color,'LineWidth',2.8);
%xlim([0 100]);
%ylim([20 47]);
set(gca,'FontSize',16)
label_x=xlabel('$Capacitance \ C \ [uF]$','Interpreter','latex','FontSize',18,'HorizontalAlignment','center');
%xlabel('\it{Capacitance C} [\it{\muF}]','FontSize',18,'HorizontalAlignment','center');
set(label_x,'rotation',0);
label_h=ylabel('$\frac{A_{1i}}{3^{rd} Harmonic} \ [dB]$','Interpreter','latex','FontSize',22,'HorizontalAlignment','center');
set(label_h,'rotation',90);
legend('\it{Q_L}=800','\it{Q_L}=600','\it{Q_L}=400','\it{Q_L}=200','Orientation','horizontal','Location','southeast','FontSize',20);
legend('boxoff')
h=gcf;
set(h,'Position',[200 200 760 580]);
grid on
grid minor

end


