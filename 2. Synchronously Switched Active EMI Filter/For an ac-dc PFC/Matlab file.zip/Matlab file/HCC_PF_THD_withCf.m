clc
clear

format long
%yellow_color = '#e2d810';
yellow_color = '#CbC000';
red_color = '#ff0000'; %'#d9138a';
blue_color = '#0000ff';%'#12a4d9';
black_color = '#322e2f';
magenta_color = '#d9138a';
cyan_color = '#12a4d9';
orange_color = '#D95319';

%% ACM: current attenuation with Cf
Cf= [3 5 7 9 11 13]*1e-6;

THD_measured_20pc=[2.67 2.9 3.5 4.1 4.59 5.77];
THD_measured_100pc=[2.71 3.48 4.5 5.51 6.66 7.7];
P_20pc=[300.3 300 300.3 300.5 300.6 300.8];
S_20pc=[301.25 301.7 302.6 303.3 304.1 305.3];
PF_20pc=P_20pc./S_20pc;

P_100pc=[223 222.9 222.85 222.8 222.2 237.4];
S_100pc=[224 224.5 225.3 226.1 226.5 242.7];
PF_100pc=P_100pc./S_100pc;

%%
figure();
%stem(Cf*1e6,PF_20pc,'o','filled','Color' , cyan_color, 'LineStyle', 'none' ,'LineWidth',6);
stem(Cf*1e6,PF_100pc,'o','filled','Color' , cyan_color, 'LineStyle', 'none' ,'LineWidth',7);
hold on
ylim([0.9 1]);
xlim([2.5 13.5]);
set(gca,'FontSize',16)
label_x=xlabel('$Capacitance \ C_f \ [\mu F]$','Interpreter','latex','FontSize',22,'HorizontalAlignment','center');
set(label_x,'rotation',0);
label_h=ylabel('$PF$','Interpreter','latex','FontSize',22,'HorizontalAlignment','center');
set(label_h,'rotation',90);
yyaxis right
%stem(Cf*1e6,THD_measured_20pc,'o','filled','Color' , magenta_color, 'LineStyle', 'none' ,'LineWidth',6);
stem(Cf*1e6,THD_measured_100pc,'o','filled','Color' , black_color, 'LineStyle', 'none' ,'LineWidth',7);
%stem(Cf*1e6,THD_analysis,'o','filled','Color' , black_color, 'LineStyle', 'none' ,'LineWidth',6);
ylim([2 8]);
ax = gca;
ax.YAxis(1).Color = 'k';
ax.YAxis(2).Color = 'k';
hold off
label_h=ylabel('$THD \ [\%]$','Interpreter','latex','FontSize',22,'HorizontalAlignment','center');
set(label_h,'rotation',90);
%legend('\it{Q_L}=1000','\it{Q_L}=800','\it{Q_L}=600','\it{Q_L}=300','\it{THD}','Orientation','horizontal','Location','southeast','FontSize',20);
%legend('Experimental Result','Analytic Result','Interpreter','latex','Orientation','horizontal','Location','southeast','FontSize',20)
legend('PF','THD','Interpreter','latex','Orientation','horizontal','Location','southeast','FontSize',22)
legend('boxoff')
My_LGD = legend;
My_LGD.NumColumns = 1;    % Show legends in 5 lines

h=gcf;
set(h,'Position',[200 200 700 360]);
grid on
text(11,3,{'$\mathcal{R}=1$'},'Interpreter','latex','Color', orange_color,'FontSize',30,'HorizontalAlignment','center');
%grid minor
