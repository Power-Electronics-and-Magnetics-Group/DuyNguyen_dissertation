clc
clear

format long
%yellow_color = '#e2d810';
yellow_color = '#CbC000';
red_color = '#ff0000'; %'#d9138a';
blue_color = '#0000ff';%'#12a4d9';
black_color = '#322e2f';
magenta_color = '#d9138a';
cyan_color = '#12a4d9';
orange_color = '#D95319';

%% For Cf=1uF
format long
data = csvread('ACM_Experiment_Cf_1uF.csv',1); % Read the data
t1 = data(2:end,2);
for i=2:(numel(t1))
    t1(i)=t1(i)-t1(1);
end
t1(1) = 0;
t1 =t1./1e6;
CH1=smooth(data(2:end,4)/1e6);  % is
CH2=smooth(data(2:end,6)/1e6);  % iconv
CH3=smooth(data(2:end,8)/1e6);  % if

%% For Cf=1uF

enable =1;
if (enable == 1)
    txx=21.3;
ffffff=find(t1>=txx/1000 & t1<=(txx+8.5)/1000);
t=t1(ffffff)-txx/1000;
CH2=CH2(ffffff);
CH3=CH3(ffffff);
CH1=CH1(ffffff);
end

%% For Cf=1uF
figure();
if (enable ==1)
    plot(t*1000,CH2,'Color' , cyan_color,'LineWidth',2.4);
    hold on
    plot(t*1000,CH3,'Color' , yellow_color,'LineWidth',2.4);
    plot(t*1000,CH1,'Color' , magenta_color,'LineWidth',2.4);
else
    plot(t1*1000,CH2,'Color' , cyan_color,'LineWidth',2.4);
    hold on
    plot(t1*1000,CH3,'Color' , yellow_color,'LineWidth',2.4);
    plot(t1*1000,CH1,'Color' , magenta_color,'LineWidth',2.4);
end
grid on
%ylim([-0.5 5]);

ylim([-1.35 5.2]);
if (enable == 1)
    xlim([0 8.5]);
else
    xlim([txx (txx+8.5)]);
end
set(gca,'FontSize',13)
label_h=ylabel('$Current \ [A]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_h,'rotation',90);
label_x=xlabel('$Time \ [ms]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_x,'rotation',0);
text(6.9,4.6,{'$C_f=1\mu F$'},'Interpreter','latex','Color', orange_color,'FontSize',17,'HorizontalAlignment','center');
grid minor
h=gcf;
%set(h,'Position',[200 200 720 570]);
set(h,'Position',[200 200 380 300]);


%% For Cf=3uF
format long
data = csvread('ACM_Experiment_Cf_3uF.csv',1); % Read the data
t1 = data(2:end,2);
for i=2:(numel(t1))
    t1(i)=t1(i)-t1(1);
end
t1(1) = 0;
t1 =t1./1e6;
CH1=smooth(data(2:end,4)/1e6);  % is
CH2=smooth(data(2:end,6)/1e6);  % iconv
CH3=smooth(data(2:end,8)/1e6);  % if

%% For Cf=3uF

enable =1;
if (enable == 1)
    txx=19.06;
ffffff=find(t1>=txx/1000 & t1<=(txx+8.5)/1000);
t=t1(ffffff)-txx/1000;
CH2=CH2(ffffff);
CH3=CH3(ffffff);
CH1=CH1(ffffff);
end

%% For Cf=3uF
figure();
if (enable ==1)
    plot(t*1000,CH2,'Color' , cyan_color,'LineWidth',2.4);
    hold on
    plot(t*1000,CH3,'Color' , yellow_color,'LineWidth',2.4);
    plot(t*1000,CH1,'Color' , magenta_color,'LineWidth',2.4);
else
    plot(t1*1000,CH2,'Color' , cyan_color,'LineWidth',2.4);
    hold on
    plot(t1*1000,CH3,'Color' , yellow_color,'LineWidth',2.4);
    plot(t1*1000,CH1,'Color' , magenta_color,'LineWidth',2.4);
end
grid on
%ylim([-0.5 5]);

ylim([-1.35 5.2]);
if (enable == 1)
    xlim([0 8.5]);
else
    xlim([txx (txx+8.5)]);
end
set(gca,'FontSize',13)
label_h=ylabel('$Current \ [A]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_h,'rotation',90);
label_x=xlabel('$Time \ [ms]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_x,'rotation',0);
text(6.9,4.6,{'$C_f=3\mu F$'},'Interpreter','latex','Color', orange_color,'FontSize',17,'HorizontalAlignment','center');
grid minor
h=gcf;
%set(h,'Position',[200 200 720 570]);
set(h,'Position',[200 200 380 300]);

%% For Cf=5uF
format long
data = csvread('ACM_Experiment_Cf_5uF.csv',1); % Read the data
t1 = data(2:end,2);
for i=2:(numel(t1))
    t1(i)=t1(i)-t1(1);
end
t1(1) = 0;
t1 =t1./1e6;
CH1=smooth(data(2:end,4)/1e6);  % is
CH2=smooth(data(2:end,6)/1e6);  % iconv
CH3=smooth(data(2:end,8)/1e6);  % if

%% For Cf=5uF

enable =1;
if (enable == 1)
    txx=19.1;
ffffff=find(t1>=txx/1000 & t1<=(txx+8.5)/1000);
t=t1(ffffff)-txx/1000;
CH2=CH2(ffffff);
CH3=CH3(ffffff);
CH1=CH1(ffffff);
end

%% For Cf=5uF
figure();
if (enable ==1)
    plot(t*1000,CH2,'Color' , cyan_color,'LineWidth',2.4);
    hold on
    plot(t*1000,CH3,'Color' , yellow_color,'LineWidth',2.4);
    plot(t*1000,CH1,'Color' , magenta_color,'LineWidth',2.4);
else
    plot(t1*1000,CH2,'Color' , cyan_color,'LineWidth',2.4);
    hold on
    plot(t1*1000,CH3,'Color' , yellow_color,'LineWidth',2.4);
    plot(t1*1000,CH1,'Color' , magenta_color,'LineWidth',2.4);
end
grid on
%ylim([-0.5 5]);

ylim([-1.35 5.2]);
if (enable == 1)
    xlim([0 8.5]);
else
    xlim([txx (txx+8.5)]);
end
set(gca,'FontSize',13)
label_h=ylabel('$Current \ [A]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_h,'rotation',90);
label_x=xlabel('$Time \ [ms]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_x,'rotation',0);
text(6.9,4.6,{'$C_f=5\mu F$'},'Interpreter','latex','Color', orange_color,'FontSize',17,'HorizontalAlignment','center');
grid minor
h=gcf;
%set(h,'Position',[200 200 720 570]);
set(h,'Position',[200 200 380 300]);

%% For Cf=7uF
format long
data = csvread('ACM_Experiment_Cf_7uF.csv',1); % Read the data
t1 = data(2:end,2);
for i=2:(numel(t1))
    t1(i)=t1(i)-t1(1);
end
t1(1) = 0;
t1 =t1./1e6;
CH1=smooth(data(2:end,4)/1e6);  % is
CH2=smooth(data(2:end,6)/1e6);  % iconv
CH3=smooth(data(2:end,8)/1e6);  % if

%% For Cf=7uF

enable =1;
if (enable == 1)
    txx=19.1;
ffffff=find(t1>=txx/1000 & t1<=(txx+8.5)/1000);
t=t1(ffffff)-txx/1000;
CH2=CH2(ffffff);
CH3=CH3(ffffff);
CH1=CH1(ffffff);
end

%% For Cf=7uF
figure();
if (enable ==1)
    plot(t*1000,CH2,'Color' , cyan_color,'LineWidth',2.4);
    hold on
    plot(t*1000,CH3,'Color' , yellow_color,'LineWidth',2.4);
    plot(t*1000,CH1,'Color' , magenta_color,'LineWidth',2.4);
else
    plot(t1*1000,CH2,'Color' , cyan_color,'LineWidth',2.4);
    hold on
    plot(t1*1000,CH3,'Color' , yellow_color,'LineWidth',2.4);
    plot(t1*1000,CH1,'Color' , magenta_color,'LineWidth',2.4);
end
grid on
%ylim([-0.5 5]);

ylim([-1.35 5.2]);
if (enable == 1)
    xlim([0 8.5]);
else
    xlim([txx (txx+8.5)]);
end
set(gca,'FontSize',13)
label_h=ylabel('$Current \ [A]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_h,'rotation',90);
label_x=xlabel('$Time \ [ms]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_x,'rotation',0);
text(6.9,4.6,{'$C_f=7\mu F$'},'Interpreter','latex','Color', orange_color,'FontSize',17,'HorizontalAlignment','center');
grid minor
h=gcf;
%set(h,'Position',[200 200 720 570]);
set(h,'Position',[200 200 380 300]);


%% For Cf=9uF
format long
data = csvread('ACM_Experiment_Cf_9uF.csv',1); % Read the data
t1 = data(2:end,2);
for i=2:(numel(t1))
    t1(i)=t1(i)-t1(1);
end
t1(1) = 0;
t1 =t1./1e6;
CH1=smooth(data(2:end,4)/1e6);  % is
CH2=smooth(data(2:end,6)/1e6);  % iconv
CH3=smooth(data(2:end,8)/1e6);  % if

%% For Cf=9uF

enable =1;
if (enable == 1)
    txx=19.1;
ffffff=find(t1>=txx/1000 & t1<=(txx+8.5)/1000);
t=t1(ffffff)-txx/1000;
CH2=CH2(ffffff);
CH3=CH3(ffffff);
CH1=CH1(ffffff);
end

%% For Cf=9uF
figure();
if (enable ==1)
    plot(t*1000,CH2,'Color' , cyan_color,'LineWidth',2.4);
    hold on
    plot(t*1000,CH3,'Color' , yellow_color,'LineWidth',2.4);
    plot(t*1000,CH1,'Color' , magenta_color,'LineWidth',2.4);
else
    plot(t1*1000,CH2,'Color' , cyan_color,'LineWidth',2.4);
    hold on
    plot(t1*1000,CH3,'Color' , yellow_color,'LineWidth',2.4);
    plot(t1*1000,CH1,'Color' , magenta_color,'LineWidth',2.4);
end
grid on
%ylim([-0.5 5]);

ylim([-1.35 5.2]);
if (enable == 1)
    xlim([0 8.5]);
else
    xlim([txx (txx+8.5)]);
end
set(gca,'FontSize',13)
label_h=ylabel('$Current \ [A]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_h,'rotation',90);
label_x=xlabel('$Time \ [ms]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_x,'rotation',0);
text(6.9,4.6,{'$C_f=9\mu F$'},'Interpreter','latex','Color', orange_color,'FontSize',17,'HorizontalAlignment','center');
grid minor
h=gcf;
%set(h,'Position',[200 200 720 570]);
set(h,'Position',[200 200 380 300]);