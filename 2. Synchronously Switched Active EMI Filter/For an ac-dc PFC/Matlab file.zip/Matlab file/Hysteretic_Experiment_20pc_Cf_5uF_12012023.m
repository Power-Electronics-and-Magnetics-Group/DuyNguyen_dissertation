clc
clear

format long
%yellow_color = '#e2d810';
yellow_color = '#CbC000';
red_color = '#ff0000'; %'#d9138a';
blue_color = '#0000ff';%'#12a4d9';
black_color = '#322e2f';
magenta_color = '#d9138a';
cyan_color = '#12a4d9';
orange_color = '#D95319';
%% For 20% ripple
format long
data = csvread('Hysteretic_Experiment_20pc_Cf_5uF.csv',1); % Read the data
t1 = data(2:end,2);
for i=2:(numel(t1))
    t1(i)=t1(i)-t1(1);
end
t1(1) = 0;
t1 =t1./1e6;
CH1=smooth(data(2:end,4)/1e6);  % is
CH2=smooth(data(2:end,6)/1e6);  % iconv
CH3=smooth(data(2:end,8)/1e6);  % if

%% For 20% ripple

enable =1;
if (enable == 1)
ffffff=find(t1>=19/1000 & t1<=27.5/1000);
t=t1(ffffff)-19/1000;
CH2=CH2(ffffff);
CH3=CH3(ffffff);
CH1=CH1(ffffff);
end
%%
figure();
if (enable ==1)
    plot(t*1000,CH2,'Color' , cyan_color,'LineWidth',2.4);
    hold on
    plot(t*1000,CH3,'Color' , yellow_color,'LineWidth',2.4);
    plot(t*1000,CH1,'Color' , magenta_color,'LineWidth',2.4);
else
    plot(t1*1000,CH2,'Color' , cyan_color,'LineWidth',2.4);
    hold on
    plot(t1*1000,CH3,'Color' , yellow_color,'LineWidth',2.4);
    plot(t1*1000,CH1,'Color' , magenta_color,'LineWidth',2.4);
end
grid on
%ylim([-0.5 5]);

ylim([-1.4 5.2]);
if (enable == 1)
    xlim([0 8.5]);
else
    xlim([19 27.5]);
end
set(gca,'FontSize',13)
label_h=ylabel('$Current \ [A]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_h,'rotation',90);
label_x=xlabel('$Time \ [ms]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_x,'rotation',0);
text(6.8,4.5,{'$\mathcal{R}=0.2$'},'Interpreter','latex','Color', orange_color,'FontSize',19,'HorizontalAlignment','center');
grid minor
h=gcf;
%set(h,'Position',[200 200 720 570]);
set(h,'Position',[200 200 380 300]);



%% For 50% ripple
format long
data = csvread('Hysteretic_Experiment_50pc_Cf_5uF.csv',1); % Read the data
t1 = data(2:end,2);
for i=2:(numel(t1))
    t1(i)=t1(i)-t1(1);
end
t1(1) = 0;
t1 =t1./1e6;
CH1=smooth(data(2:end,4)/1e6);  % is
CH2=smooth(data(2:end,6)/1e6);  % iconv
CH3=smooth(data(2:end,8)/1e6);  % if

%%

enable =1;
if (enable == 1)
ffffff=find(t1>=19/1000 & t1<=27.5/1000);
t=t1(ffffff)-19/1000;
CH2=CH2(ffffff);
CH3=CH3(ffffff);
CH1=CH1(ffffff);
end
%%
figure();
if (enable ==1)
    plot(t*1000,CH2,'Color' , cyan_color,'LineWidth',2.4);
    hold on
    plot(t*1000,CH3,'Color' , yellow_color,'LineWidth',2.4);
    plot(t*1000,CH1,'Color' , magenta_color,'LineWidth',2.4);
else
    plot(t1*1000,CH2,'Color' , cyan_color,'LineWidth',2.4);
    hold on
    plot(t1*1000,CH3,'Color' , yellow_color,'LineWidth',2.4);
    plot(t1*1000,CH1,'Color' , magenta_color,'LineWidth',2.4);
end
grid on
%ylim([-0.5 5]);

ylim([-2.5 6.3]);
if (enable == 1)
    xlim([0 8.5]);
else
    xlim([19 27.5]);
end
set(gca,'FontSize',13)
label_h=ylabel('$Current \ [A]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_h,'rotation',90);
label_x=xlabel('$Time \ [ms]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_x,'rotation',0);
text(6.8,5.5,{'$\mathcal{R}=0.5$'},'Interpreter','latex','Color', orange_color,'FontSize',19,'HorizontalAlignment','center');
grid minor
h=gcf;
if (enable == 1)
%set(h,'Position',[200 200 720 570]);
set(h,'Position',[200 200 380 300]);
end


%% For 80% ripple
format long
data = csvread('Hysteretic_Experiment_80pc_Cf_5uF.csv',1); % Read the data
t1 = data(2:end,2);
for i=2:(numel(t1))
    t1(i)=t1(i)-t1(1);
end
t1(1) = 0;
t1 =t1./1e6;
CH1=smooth(data(2:end,4)/1e6);  % is
CH2=smooth(data(2:end,6)/1e6);  % iconv
CH3=smooth(data(2:end,8)/1e6);  % if

%%

enable =1;
if (enable == 1)
ffffff=find(t1>=17.5/1000 & t1<=(17.5+8.5)/1000);
t=t1(ffffff)-17.5/1000;
CH2=CH2(ffffff);
CH3=CH3(ffffff);
CH1=CH1(ffffff);
end
%%
figure();
if (enable ==1)
    plot(t*1000,CH2*1.065,'Color' , cyan_color,'LineWidth',2.4);
    hold on
    plot(t*1000,CH3*1.065,'Color' , yellow_color,'LineWidth',2.4);
    plot(t*1000,CH1,'Color' , magenta_color,'LineWidth',2.4);
else
    plot(t1*1000,CH2*1.065,'Color' , cyan_color,'LineWidth',2.4);
    hold on
    plot(t1*1000,CH3*1.065,'Color' , yellow_color,'LineWidth',2.4);
    plot(t1*1000,CH1,'Color' , magenta_color,'LineWidth',2.4);
end
grid on
%ylim([-0.5 5]);

ylim([-3.8 7]);
if (enable == 1)
    xlim([0 8.5]);
else
    %xlim([19 27.5]);
end
set(gca,'FontSize',13)
label_h=ylabel('$Current \ [A]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_h,'rotation',90);
label_x=xlabel('$Time \ [ms]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_x,'rotation',0);
text(7,5.8,{'$\mathcal{R}=0.8$'},'Interpreter','latex','Color', orange_color,'FontSize',19,'HorizontalAlignment','center');
grid minor
h=gcf;
if (enable == 1)
%set(h,'Position',[200 200 720 570]);
set(h,'Position',[200 200 380 300]);
end


%% For 100% ripple
format long
data = csvread('Hysteretic_Experiment_100pc_Cf_5uF.csv',1); % Read the data
t1 = data(2:end,2);
for i=2:(numel(t1))
    t1(i)=t1(i)-t1(1);
end
t1(1) = 0;
t1 =t1./1e6;
CH1=smooth(data(2:end,4)/1e6);  % is
CH2=smooth(data(2:end,6)/1e6);  % iconv
CH3=smooth(data(2:end,8)/1e6);  % if

%%

enable =1;
if (enable == 1)
ffffff=find(t1>=21.3/1000 & t1<=(21.3+8.5)/1000);
t=t1(ffffff)-21.3/1000;
CH2=CH2(ffffff);
CH3=CH3(ffffff);
CH1=CH1(ffffff);
end
%%
figure();
if (enable ==1)
    plot(t*1000,CH2*1.095,'Color' , cyan_color,'LineWidth',2.4);
    hold on
    plot(t*1000,CH3*1.095,'Color' , yellow_color,'LineWidth',2.4);
    plot(t*1000,CH1,'Color' , magenta_color,'LineWidth',2.4);
else
    plot(t1*1000,CH2*1.095,'Color' , cyan_color,'LineWidth',2.4);
    hold on
    plot(t1*1000,CH3*1.095,'Color' , yellow_color,'LineWidth',2.4);
    plot(t1*1000,CH1,'Color' , magenta_color,'LineWidth',2.4);
end
grid on
%ylim([-0.5 5]);

ylim([-4.4 7.7]);
if (enable == 1)
    xlim([0 8.5]);
else
    %xlim([19 27.5]);
end
set(gca,'FontSize',13)
label_h=ylabel('$Current \ [A]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_h,'rotation',90);
label_x=xlabel('$Time \ [ms]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_x,'rotation',0);
text(7,6.2,{'$\mathcal{R}=1$'},'Interpreter','latex','Color', orange_color,'FontSize',19,'HorizontalAlignment','center');
grid minor
h=gcf;
if (enable == 1)
%set(h,'Position',[200 200 720 570]);
set(h,'Position',[200 200 380 300]);
end
