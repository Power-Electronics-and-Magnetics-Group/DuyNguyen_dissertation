clc
clear

format long
%yellow_color = '#e2d810';
yellow_color = '#CbC000';
red_color = '#ff0000'; %'#d9138a';
blue_color = '#0000ff';%'#12a4d9';
black_color = '#322e2f';
magenta_color = '#d9138a';
cyan_color = '#12a4d9';
orange_color = '#D95319';

%% ACM: current attenuation with Cf
Cf= [3 5 7 9 11 13]*1e-6;
%A1s=[-22.2 -32.5 -35.3 -34.6 -35.3 -34.6 -34.3];
% This is results from spectrum analyzer with 100mV/A attenuation
A1conv_RR20pc=[-25.2 -25.32   -25.22  -26.15 -25.39 -25.59];
A1conv_RR50pc=[-16.8 -16.68  -16.7   -16.85 -16.87 -16.65];
A1conv_RR100pc=[-13.67 -13.48 -13.4    -13.26 -13.35 -13.08];

A1s_RR20pc=[-60.52 -61.01 -61.5    -62.24 -60.91 -60.59];
A1s_RR50pc=[-39.84 -42.2  -43.5   -45.4 -44.98 -44.73];
A1s_RR100pc=[-29.64 -33.18   -35.38  -37.61 -37.92 -35.42];

A1i_20pc=A1s_RR20pc-A1conv_RR20pc;
A1i_50pc=A1s_RR50pc-A1conv_RR50pc;
A1i_100pc=A1s_RR100pc-A1conv_RR100pc

A1i_analysis_20pc=[37.1 39.58 40.4 41 41.1 41.2]; %Rf=0.05
A1i_analysis_50pc=[27 30.3 32.7 34 35 35.4]; %Rf=0.05
A1i_analysis_100pc=[18.68 20.5 23 24.6 25.9 26.9]; %Rf=0.05

%%
figure();
stem(Cf*1e6,abs(A1i_50pc),'o','filled','Color' , black_color, 'LineStyle', 'none' ,'LineWidth',5);
hold on
stem(Cf*1e6,A1i_analysis_50pc,'+','filled','Color' , black_color, 'LineStyle', 'none' ,'LineWidth',2.5);
stem(Cf*1e6,abs(A1i_20pc),'o','filled','Color' , magenta_color, 'LineStyle', 'none' ,'LineWidth',5);
hold on
stem(Cf*1e6,A1i_analysis_20pc,'+','filled','Color' , magenta_color, 'LineStyle', 'none' ,'LineWidth',2.5);
stem(Cf*1e6,abs(A1i_100pc),'o','filled','Color' , yellow_color, 'LineStyle', 'none' ,'LineWidth',5);
stem(Cf*1e6,A1i_analysis_100pc,'+','filled','Color' , yellow_color, 'LineStyle', 'none' ,'LineWidth',2.5);
ylim([5 43]);
xlim([2 14]);

set(gca,'FontSize',16)
label_x=xlabel('$Capacitance \ C_f \ [\mu F]$','Interpreter','latex','FontSize',22,'HorizontalAlignment','center');
set(label_x,'rotation',0);
label_h=ylabel('$A_{1i} \ [dB]$','Interpreter','latex','FontSize',22,'HorizontalAlignment','center');
set(label_h,'rotation',90);
%legend('\it{Q_L}=1000','\it{Q_L}=800','\it{Q_L}=600','\it{Q_L}=300','\it{THD}','Orientation','horizontal','Location','southeast','FontSize',20);
legend('Experimental Result','Analytic Result','Interpreter','latex','Orientation','horizontal','Location','southeast','FontSize',20)
legend('boxoff')
My_LGD = legend;
My_LGD.NumColumns = 1;    % Show legends in 5 lines
h=gcf;
%set(h,'Position',[200 200 700 360]);
set(h,'Position',[200 200 720 500]);
grid on

text(2.9,13.6,{'$\mathcal{R}=1$'},'Interpreter','latex','Color', yellow_color,'FontSize',17,'HorizontalAlignment','center');
text(3,28.5,{'$\mathcal{R}=0.5$'},'Interpreter','latex','Color', black_color,'FontSize',17,'HorizontalAlignment','center');
text(3,38.5,{'$\mathcal{R}=0.2$'},'Interpreter','latex','Color', magenta_color,'FontSize',17,'HorizontalAlignment','center');

%grid minor
