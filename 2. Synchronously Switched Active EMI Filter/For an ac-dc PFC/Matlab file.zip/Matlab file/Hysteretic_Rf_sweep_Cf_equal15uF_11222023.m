% This is for hysteretic control. No sweep
clc
clear

format long
%yellow_color = '#e2d810';
yellow_color = '#CbC000';
red_color = '#ff0000'; %'#d9138a';
blue_color = '#0000ff';%'#12a4d9';
black_color = '#322e2f';
magenta_color = '#d9138a';
cyan_color = '#12a4d9';
orange_color = '#D95319';
%% Design control loop for PFC boost converter - Average current control mode

%Converter information
Vac_rms=110; % Need to consider Vg_max, Vg_min
Vac_pk=Vac_rms*2^0.5;
fline=60;
Tline=1/fline;
wline=2*pi*fline;
T0=Tline/2;f0=1/T0;
w0=2*wline;
Pout=300;
Pav=Pout;
Vout=400;
fsw=150e3; Tsw=1/fsw;
wsw=2*pi*fsw;


Re=Vac_rms^2/Pav; % Equivalent input impedance at the source
Lf=6.2e-6;
%Resr=0.1;
Cf=10e-6;   % Capacitor of AEF

C=500e-6;
L=240e-6; 
R=0.28;
Q_i = [800 600 400 200]; % quality of the boost inductor
Ro_i = wsw*L./Q_i; % Parasitic resistor of boost circuit

Rf_i=linspace(0.05,1,50);

%Rf_i=linspace(0,1,50);
RR_i=[0.2 0.5 1];
RR=0.2;
Gain_H=(1+RR);
Gain_L=(1-RR);

Vg=Vout*(Lf/L);

Tswmax=(Gain_H-Gain_L)*L/Re + (Gain_H-Gain_L)*Vac_pk*L/((Vout-Vac_pk)*Re);
fswmin=1/Tswmax;
Cmin=ceil(1/(4*pi^2*fswmin^2*Lf)*1e6)/1e6 + 1e-6;
if (Cmin <= 1e-6)
    Cmin=1e-6;
end

Cf_i = [15e-6];   % Capacitor of AEF
%Cf_i = linspace(Cmin,30e-6,30);   % Capacitor of AEF
[Ro_m,Rf_m] = meshgrid(Ro_i,Rf_i);

attenuation_Ai = zeros(numel(Rf_i),numel(Ro_i));
attenuation_Ai_RR1 = zeros(numel(Rf_i),numel(Ro_i));
attenuation_Ai_RR2 = zeros(numel(Rf_i),numel(Ro_i));

syms x

for ff=1:length(RR_i)
    Cf=Cf_i(1);
    Gain_H=(1+RR_i(ff));
    Gain_L=(1-RR_i(ff));
    for k=1:numel(Rf_i)
        for n=1:numel(Ro_i)
                R = Ro_m(k,n);
                Resr=Rf_m(k,n);
                w0res=1/(Lf*Cf)^0.5;
                %w0res=(4*Lf*Cf-Resr^2*Cf^2)^0.5/(2*Lf*Cf);
                T0res=2*pi/w0res;
                lamda=-Resr/(2*Lf);
                %damping_factor = -lamda/w0res;
                %wd=w0res*(1-damping_factor^2)^0.5;
        
                tx=(atan(-wline*Cf*Re)+pi)/wline;
                k1=Vac_pk*sin(wline*tx);
                
                ty = vpasolve(k1*exp(-(x-tx)/(Re*Cf)) == -Vac_pk*sin(wline*x),x);
                if (ty > 2*T0) 
                    t0=0;
                else
                    t0=double(ty-Tline/2);
                end 
                t1=double(tx);
                t_total=double(t0+(Tline/2-tx));
            
                Tsample = 0.5e-8;    % 10ns sampling time
                cdf=ceil((t1-t0)/Tsample);
                torigin=0; status = 1;
                g_cnt=0;
                nsample_total = ceil(T0/Tsample);
                iL_boost = zeros(1, nsample_total);
                iL_aef = zeros(1, nsample_total);
                time = zeros(1, nsample_total);
    %%    
            while  torigin <= T0
                if (torigin <= cdf*Tsample)
                        Vrec1=Vac_pk*abs(sin(wline*(torigin+t0))); % [ t0, t1]
                        iL_aef_avg1=wline*Cf*Vac_pk*cos(wline*(torigin+t0));
                        Iboost_avg1=Vrec1/Re;
                        %if (status == 1)
                            ton=(Gain_H-Gain_L)*L/(Re-Gain_H*wline*L*cot(wline*(torigin+t0)));
                            xyz_on=ceil(ton/Tsample);
                            ton=xyz_on*Tsample;
                        %else
                            Vrec2=Vac_pk*abs(sin(wline*(torigin+t0+ton))); % [ t0, t1]
                            iL_aef_avg2=wline*Cf*Vac_pk*cos(wline*(torigin+t0+ton));
                            Iboost_avg2=Vrec2/Re;
                            toff=((Gain_H-Gain_L)*L*Vrec2)/((Vout-Vrec2)*Re+Gain_L*Vac_pk*wline*L*cos(wline*(torigin+t0+ton)));
                            xyz_off=ceil(toff/Tsample);
                            toff=xyz_off*Tsample;  
                        %end
                else
                        Vrec1=k1*exp(-(torigin-cdf*Tsample)/(Re*Cf)); % [t1,T0] and [T0,T0+t0]
                        iL_aef_avg1=(-k1/Re)*exp(-(torigin-cdf*Tsample)/(Re*Cf));
                        Iboost_avg1=Vrec1/Re;
                        %if (status == 1)
                            ton=(Gain_H-Gain_L)/(Re/L+Gain_H/(Re*C));
                            xyz_on=ceil(ton/Tsample);
                            ton=xyz_on*Tsample;
                        %else
                            Vrec2=k1*exp(-(torigin-cdf*Tsample+ton)/(Re*Cf)); % [t1,T0] and [T0,T0+t0]
                            iL_aef_avg2=(-k1/Re)*exp(-(torigin-cdf*Tsample+ton)/(Re*Cf));
                            Iboost_avg2=Vrec2/Re;
                            toff=((Gain_H-Gain_L))/((Vout/Vrec2-1)*(Re/L)-Gain_L/(Re*C));
                            xyz_off=ceil(toff/Tsample);
                            toff=xyz_off*Tsample;
                        %end
                end
    %%
                torigin = torigin+(ton+toff);
                % For boost converter
                Iboost_min=(Iboost_avg1-Vrec1/(2*L)*(ton));
                Iboost_max=(Iboost_avg2+(Vout-Vrec2)/(2*L)*(toff));
                
                % For the AEF
                delta_I_conv1=(Vrec1/L)*(ton); % Imax-Imin in one switching cycle
                delta_I_conv2=((Vout-Vrec2)/L)*(toff); 
                Iaef_max1 = delta_I_conv1/2 + iL_aef_avg1;
                Iaef_min1 = -delta_I_conv1/2 + iL_aef_avg1;
                Iaef_max2 = delta_I_conv2/2 + iL_aef_avg2;
                Iaef_min2 = -delta_I_conv2/2 + iL_aef_avg2;
    
                xx=exp(lamda*ton)*cos(w0res*ton);
                yy=exp(lamda*ton)*sin(w0res*ton);
                zz=exp(lamda*(toff))*cos(w0res*(toff));
                tt=exp(lamda*(toff))*sin(w0res*(toff));
                A1=Iaef_max1;
                A2=(Iaef_min1-Iaef_max1*xx)/yy;
                A3=Iaef_min2;
                A4=(Iaef_max2-Iaef_min2*zz)/tt;
    
                for m=1:(xyz_on+xyz_off-1)
                    g_cnt = g_cnt + 1;
                    if (m < xyz_on)  
                        iL_boost(g_cnt)= (Iboost_min*exp(-R*(m-1)*Tsample/L) + ((Vrec1)/R)*(1-exp(-R*(m-1)*Tsample/L)));
                        %Imaxx=iL_boost(g_cnt);
                    else              
                        iL_boost(g_cnt)= (Iboost_max*exp(-R*((m-1)*Tsample-ton)/L) + ((Vrec2-Vout)/R)*(1-exp(-R*((m-1)*Tsample-ton)/L)));
                    end
        
                    if (m < xyz_on)
                        iL_aef(g_cnt)=exp(lamda*(m-1)*Tsample)*(A1*cos(w0res*(m-1)*Tsample)+A2*sin(w0res*(m-1)*Tsample));
                    else
                        iL_aef(g_cnt)=exp(lamda*((m-1)*Tsample-ton))*(A3*cos(w0res*((m-1)*Tsample-ton))+A4*sin(w0res*((m-1)*Tsample-ton)));
                    end
                    time(g_cnt)=(g_cnt-1)*Tsample;
                end
            end
            
            %isum=iL_boost+iL_aef;
            No_cycles_120Hz=3;
            times_total = zeros(No_cycles_120Hz,numel(time));
            iL_boost_total = zeros(No_cycles_120Hz,numel(time));
            iL_aef_total = zeros(No_cycles_120Hz,numel(time));
            %isum_total = zeros(No_cycles_120Hz,numel(time));
            for n_cycles_=1:No_cycles_120Hz
                times_total(n_cycles_,:)=(n_cycles_-1)*T0+time;
                iL_boost_total(n_cycles_,:)=iL_boost;
                iL_aef_total(n_cycles_,:)=iL_aef;
                %isum_total(n_cycles_,:)=isum;
            end
    
            times_total=reshape(times_total.',1,[]);
            iL_boost_total=reshape(iL_boost_total.',1,[]);
            iL_aef_total=reshape(iL_aef_total.',1,[]);
            isum_total=iL_boost_total+iL_aef_total;
    
            ddTsample = mean(diff(times_total)); % sampling interval
            Fs = 1/ddTsample;
            Fn = Fs/2;
            N = length(times_total);
            fft_isum = fft(isum_total)/N;
            fft_i_boost = fft(iL_boost_total)/N;
            Fv = linspace(0, 1, fix(N/2)+1)*Fn;                 % Frequency Vector
            Iv = 1:length(Fv);   
            fft_i_sum_mag=mag2db(abs(fft_isum(Iv)));
            fft_i_boost_mag=mag2db(abs(fft_i_boost(Iv)));
            fft_Ai_dB=fft_i_sum_mag-fft_i_boost_mag;
    
            %boost_Ai = max(fft_i_boost_mag(Fv>50000));
            %ffffff=find(fft_i_boost_mag == boost_Ai);
            if (ff == 1)
                boost_Ai = max(fft_i_boost_mag(6400:6440));
            elseif (ff == 2)
                boost_Ai = max(fft_i_boost_mag(2560:2600));
            else
                boost_Ai = max(fft_i_boost_mag(1280:1310));
            end
            ffffff=find(fft_i_boost_mag == boost_Ai);
            source_Ai  = max(fft_i_sum_mag(ffffff));
            attenuation_Ai(k,n) = (source_Ai-boost_Ai);
        end
    end %for k=1:numel(Cf_i)
    if(ff == 1)
        attenuation_Ai_RR1 = attenuation_Ai;
    elseif (ff==2)
        attenuation_Ai_RR2 = attenuation_Ai;
    end
end

%%
if(0)
fil_cnt=20;
for i=(length(Cf_i)+1):(length(Cf_i)+fil_cnt)
    attenuation_Ai(i,1)=attenuation_Ai(i-1,1);
    attenuation_Ai(i,2)=attenuation_Ai(i-1,2);
    attenuation_Ai(i,3)=attenuation_Ai(i-1,3);
    attenuation_Ai(i,4)=attenuation_Ai(i-1,4);
end
a1=smooth(attenuation_Ai(:,1),5);
a2=smooth(attenuation_Ai(:,2),5);
a3=smooth(attenuation_Ai(:,3),5);
a4=smooth(attenuation_Ai(:,4),5);
a1(30)=a1(29)-abs(((a1(28)-a1(29))));
a2(30)=a2(29)-abs(((a2(28)-a2(29))));
a3(30)=a3(29)-abs(((a3(28)-a3(29))));
a4(30)=a4(29)-abs(((a4(28)-a4(29))));
a1=smooth(smooth(smooth(a1(1:30))));
a2=smooth(smooth(smooth(a2(1:30))));
a3=smooth(smooth(smooth(a3(1:30))));
a4=smooth(smooth(smooth(a4(1:30))));
end

figure();
%yyaxis left
plot(Rf_i,abs(smooth(attenuation_Ai(:,1))),'Color' , cyan_color,'LineWidth',4.5);
hold on
plot(Rf_i,abs(smooth(attenuation_Ai(:,2))),'Color' , magenta_color,'LineWidth',4.5);
plot(Rf_i,abs(smooth(attenuation_Ai(:,3))),'Color' , yellow_color,'LineWidth',4.5);
plot(Rf_i,abs(smooth(attenuation_Ai(:,4))),'Color' , black_color,'LineWidth',4.5);

plot(Rf_i,abs(smooth(attenuation_Ai_RR1(:,1))),'Color' , cyan_color,'LineWidth',4.5);
plot(Rf_i,abs(smooth(attenuation_Ai_RR1(:,2))),'Color' , magenta_color,'LineWidth',4.5);
plot(Rf_i,abs(smooth(attenuation_Ai_RR1(:,3))),'Color' , yellow_color,'LineWidth',4.5);
plot(Rf_i,abs(smooth(attenuation_Ai_RR1(:,4))),'Color' , black_color,'LineWidth',4.5);

plot(Rf_i,abs(smooth(attenuation_Ai_RR2(:,1))),'Color' , cyan_color,'LineWidth',4.5);
plot(Rf_i,abs(smooth(attenuation_Ai_RR2(:,2))),'Color' , magenta_color,'LineWidth',4.5);
plot(Rf_i,abs(smooth(attenuation_Ai_RR2(:,3))),'Color' , yellow_color,'LineWidth',4.5);
plot(Rf_i,abs(smooth(attenuation_Ai_RR2(:,4))),'Color' , black_color,'LineWidth',4.5);


xlim([0.05 1]);
ylim([3 41]);
set(gca,'FontSize',16)
label_x=xlabel('$R_{f} \ [\Omega]$','Interpreter','latex','FontSize',22,'HorizontalAlignment','center');
%xlabel('\it{Capacitance C} [\it{\muF}]','FontSize',18,'HorizontalAlignment','center');
set(label_x,'rotation',0);
label_h=ylabel('$A_{1i} \ [dB]$','Interpreter','latex','FontSize',22,'HorizontalAlignment','center');
set(label_h,'rotation',90);
hold off
%legend('\it{Q_L}=1000','\it{Q_L}=800','\it{Q_L}=600','\it{Q_L}=300','\it{THD}','Orientation','horizontal','Location','southeast','FontSize',20);
legend('$Q_L=800$','$Q_L=600$','$Q_L=400$','$Q_L=200$','Interpreter','latex','Orientation','horizontal','Location','southeast','FontSize',20)
legend('boxoff')
My_LGD = legend;
My_LGD.NumColumns = 2;    % Show legends in 5 lines
h=gcf;
set(h,'Position',[200 200 720 570]);
%grid on
grid minor

ar = annotation("arrow");
ar.Color = "black";
ar.LineStyle="--";
ar.LineWidth=3;
ar.X=[0.315 0.38];
ar.Y=[0.26 0.33];
text(0.27,8.5,{'$\mathcal{R}=1$'},'Interpreter','latex','Color' , orange_color,'FontSize',19,'HorizontalAlignment','center');

ar = annotation("arrow");
ar.Color = "black";
ar.LineStyle="--";
ar.LineWidth=3;
ar.X=[0.665 0.72];
ar.Y=[0.295 0.34];
text(0.71,10.3,{'$\mathcal{R}=0.5$'},'Interpreter','latex','Color', orange_color,'FontSize',19,'HorizontalAlignment','center');

ar = annotation("arrow");
ar.Color = "black";
ar.LineStyle="--";
ar.LineWidth=3;
ar.X=[0.725 0.655];
ar.Y=[0.611 0.5501];

text(0.79,27.3,{'$\mathcal{R}=0.2$'},'Interpreter','latex','Color', orange_color,'FontSize',19,'HorizontalAlignment','center');
%set(gca,'box','off')