% Use to sweep R and Cf. It works but the analysis is not
% accurate 11/12/2023
clc
clear

format long
%yellow_color = '#e2d810';
yellow_color = '#CbC000';
red_color = '#ff0000'; %'#d9138a';
blue_color = '#0000ff';%'#12a4d9';
black_color = '#322e2f';

magenta_color = '#d9138a';
cyan_color = '#12a4d9';
orange_color = '#D95319';

%% Design control loop for PFC boost converter - Average current control mode

%Converter information
Vac_rms=110; % Need to consider Vg_max, Vg_min
Vac_pk=Vac_rms*2^0.5;
fline=60;
Tline=1/fline;
wline=2*pi*fline;
T0=Tline/2;f0=1/T0;
w0=2*wline;
Pout=300;
Pav=Pout;
Vout=400;
fsw=150e3; Tsw=1/fsw;
wsw=2*pi*fsw;


Re=Vac_rms^2/Pav; % Equivalent input impedance at the source
Lf=6.2e-6;
%Resr=0.01;
%Cf_i = 1e-6:0.5e-6:30e-6;   % Capacitor of AEF
Cf_i = [1e-6 10e-6];   % Capacitor of AEF

C=500e-6;
L=240e-6; 
%R=0.05;
%Q_i = [1000 800 600 300]; % quality of the boost inductor
Q_i = [600 400 200 100]; % quality of the boost inductor
Ro_i = wsw*L./Q_i; % Parasitic resistor of boost circuit

%nTau=(L/R)/(Lf/Resr)
%nTau=linspace(0,50,50);
Rf_i=linspace(0.05,1,50);
%abcdef=(Rf_i.^2*Cf - 4*Lf*Cf);


Vg=Vout*(Lf/L);

[Ro_m,Rf_m] = meshgrid(Ro_i,Rf_i);

Order_of_harmonics = 10;
attenuation_1st_Ai = zeros(numel(Rf_i),numel(Ro_i));
attenuation_2nd_Ai = zeros(numel(Rf_i),numel(Ro_i));
%attenuation_3rd_Ai = zeros(numel(Rf_i),numel(Ro_i));
%attenuation_4th_Ai = zeros(numel(Rf_i),numel(Ro_i));
%attenuation_5th_Ai = zeros(numel(Rf_i),numel(Ro_i));

syms x

for ff=1:length(Cf_i)
    Cf=Cf_i(ff);
    for k=1:numel(Rf_i)
        for n=1:numel(Ro_i)
            R = Ro_m(k,n);
            Resr=Rf_m(k,n);
            w0res=1/(Lf*Cf)^0.5;
            %w0res=(4*Lf*Cf-Resr^2*Cf^2)^0.5/(2*Lf*Cf);
            T0res=2*pi/w0res;
            lamda=-Resr/(2*Lf);
            damping_factor = -lamda/w0res;
            wd=w0res*(1-damping_factor^2)^0.5;
    
            tx=(atan(-wline*Cf*Re)+pi)/wline;
            k1=Vac_pk*sin(wline*tx);
            
            ty = vpasolve(k1*exp(-(x-tx)/(Re*Cf)) == -Vac_pk*sin(wline*x),x);
            if (ty > 2*T0) 
                t0=0;
            else
                t0=double(ty-Tline/2);
            end 
            t1=double(tx);
            t_total=double(t0+(Tline/2-tx));
        
            No_cycles_Tsw=fsw/f0;
           
            sample_per_Tsw = 2000;
            t=linspace(0,Tsw,sample_per_Tsw);
            Tsample = mean(diff(t));
            
            iL_boost = zeros(No_cycles_Tsw, sample_per_Tsw-1);
            iL_aef = zeros(No_cycles_Tsw, sample_per_Tsw-1);
            %iL_aef_avg = zeros(No_cycles_Tsw, sample_per_Tsw-1);
            time = zeros(No_cycles_Tsw, sample_per_Tsw-1);
            %vaa=[];
            for n_cycles=1:No_cycles_Tsw
                cdf=ceil((-Tsw/2+t1-t0)/Tsw);
                mlk=ceil((Tsw/2+t0)/Tsample);
                if ((n_cycles-1)*Tsw <= cdf*Tsw)
                    Vrec=Vac_pk*abs(sin(wline*((n_cycles-1)*Tsw+Tsw/2+t0))); % [ t0, t1]
                    iL_aef_avg=wline*Cf*Vac_pk*cos(wline*((n_cycles-1)*Tsw+Tsw/2+t0));
                    %vaa=[vaa Vrec];
                else
                    Vrec=k1*exp(-((n_cycles-1)*Tsw-cdf*Tsw)/(Re*Cf)); % [t1,T0] and [T0,T0+t0]
                    iL_aef_avg=(-k1/Re)*exp(-((n_cycles-1)*Tsw-cdf*Tsw)/(Re*Cf));
                    %vaa=[vaa Vrec];
                end
                % For boost converter
                Iboost_avg=Vrec/Re;
                duty_cycle_avg=(1-Vrec/Vout);
                abc=duty_cycle_avg*Tsw/Tsample;
                nTsample=ceil(abc); % round up
    
                Iboost_min=(Iboost_avg-Vrec/(2*L)*(nTsample*Tsample));
                Iboost_max=(Iboost_avg+(Vrec)/(2*L)*(nTsample*Tsample));
                
                % For the AEF
                delta_I_conv=(Vrec/L)*(nTsample*Tsample); % Imax-Imin in one switching cycle
                Iaef_max = delta_I_conv/2 + iL_aef_avg;
                Iaef_min = -delta_I_conv/2 + iL_aef_avg;
                
                xx=exp(lamda*nTsample*Tsample)*cos(w0res*nTsample*Tsample);
                yy=exp(lamda*nTsample*Tsample)*sin(w0res*nTsample*Tsample);
                zz=exp(lamda*(Tsw-nTsample*Tsample))*cos(w0res*(Tsw-nTsample*Tsample));
                tt=exp(lamda*(Tsw-nTsample*Tsample))*sin(w0res*(Tsw-nTsample*Tsample));
                A1=Iaef_max;
                A2=(Iaef_min-Iaef_max*xx)/yy;
                A3=Iaef_min;
                A4=(Iaef_max-Iaef_min*zz)/tt;
        
                for m=1:(numel(t))
                    if (mod(t(m),Tsw) <= nTsample*Tsample)  
                        %iL_boost=[iL_boost (Imin*exp(-R*mod(t(m),Tsw)/L) + ((Vrec)/R)*(1-exp(-R*mod(t(m),Tsw)/L)))];
                        iL_boost(n_cycles,m)= (Iboost_min*exp(-R*mod(t(m),Tsw)/L) + ((Vrec)/R)*(1-exp(-R*mod(t(m),Tsw)/L)))-Iboost_avg;
                        %Imaxx=iL_boost(n_cycles,m);
                    elseif ((mod(t(m),Tsw) > nTsample*Tsample) && (mod(t(m),Tsw) <= (Tsw)))                
                        %iL_boost=[iL_boost (Imax*exp(-R*(mod(t(m),Tsw)-duty_cycle_avg*Tsw)/L) + ((Vrec-Vout)/R)*(1-exp(-R*(mod(t(m),Tsw)-duty_cycle_avg*Tsw)/L)))];
                        iL_boost(n_cycles,m)= (Iboost_max*exp(-R*(mod(t(m),Tsw)-nTsample*Tsample)/L) + ((Vrec-Vout)/R)*(1-exp(-R*(mod(t(m),Tsw)-nTsample*Tsample)/L)))-Iboost_avg;
                    end
        
                    if (mod(t(m),Tsw) <= nTsample*Tsample)
                        iL_aef(n_cycles,m)=exp(lamda*mod(t(m),Tsw))*(A1*cos(w0res*mod(t(m),Tsw))+A2*sin(w0res*mod(t(m),Tsw)))-iL_aef_avg;
                    elseif ((mod(t(m),Tsw) > nTsample*Tsample) && (mod(t(m),Tsw) <= (Tsw)))
                        iL_aef(n_cycles,m)=exp(lamda*(mod(t(m),Tsw)-nTsample*Tsample))*(A3*cos(w0res*(mod(t(m),Tsw)-nTsample*Tsample))+A4*sin(w0res*(mod(t(m),Tsw)-nTsample*Tsample)))-iL_aef_avg;
                    end
                    time(n_cycles,m)=(n_cycles-1)*Tsw+t(m);
                end
            end %for n_cycles=1:No_cycles_Tsw
    
        %iL_boost=iL_boost-Iboost_avg;
        isum=iL_boost+iL_aef;
        time=reshape(time.',1,[]);
        iL_boost=reshape(iL_boost.',1,[]);
        iL_aef=reshape(iL_aef.',1,[]);
        isum=reshape(isum.',1,[]);
    
        Tsample = mean(diff(time)); % sampling interval
        Fs = 1/Tsample;
        Fn = Fs/2;
        N = length(time);
        fft_isum = fft(isum)/N;
        fft_i_boost = fft(iL_boost)/N;
        Fv = linspace(0, 1, fix(N/2)+1)*Fn;                 % Frequency Vector
        Iv = 1:length(Fv);   
        fft_i_sum_mag=mag2db(abs(fft_isum(Iv)));
        fft_i_boost_mag=mag2db(abs(fft_i_boost(Iv)));
        fft_Ai_dB=fft_i_sum_mag-fft_i_boost_mag;
           
        attenuation_1st_Ai(k,n)=min(fft_Ai_dB(Fv>=(fsw*1-2) & Fv<=(fsw*1+2)));
        attenuation_2nd_Ai(k,n)=min(fft_Ai_dB(Fv>=(fsw*2-1) & Fv<=(fsw*2+1)));
        %attenuation_3rd_Ai(k,n)=min(fft_Ai_dB(Fv>=(fsw*3-5e3) & Fv<=(fsw*3+5e3)));
        %attenuation_4th_Ai(k,n)=min(fft_Ai_dB(Fv>=(fsw*4-5e3) & Fv<=(fsw*4+5e3)));
        %attenuation_5th_Ai(k,n)=min(fft_Ai_dB(Fv>=(fsw*5-5e3) & Fv<=(fsw*5+5e3)));
        end
    end %for k=1:numel(Cf_i)
    if (ff==1)
        attenuation_1st_Ai_C1=attenuation_1st_Ai;
        attenuation_2nd_Ai_C1=attenuation_2nd_Ai;
    end
end

%%
figure();
%yyaxis left
plot(Rf_i,abs(attenuation_1st_Ai(:,1)),'Color' , cyan_color,'LineWidth',5);
hold on
plot(Rf_i,abs(attenuation_1st_Ai(:,2)),'Color' , magenta_color,'LineWidth',5);
plot(Rf_i,abs(attenuation_1st_Ai(:,3)),'Color' , yellow_color,'LineWidth',5);
plot(Rf_i,abs(attenuation_1st_Ai(:,4)),'Color' , black_color,'LineWidth',5);

plot(Rf_i,abs(attenuation_1st_Ai_C1(:,1)),'Color' , cyan_color,'LineWidth',5);
plot(Rf_i,abs(attenuation_1st_Ai_C1(:,2)),'Color' , magenta_color,'LineWidth',5);
plot(Rf_i,abs(attenuation_1st_Ai_C1(:,3)),'Color' , yellow_color,'LineWidth',5);
plot(Rf_i,abs(attenuation_1st_Ai_C1(:,4)),'Color' , black_color,'LineWidth',5);

xlim([0.05 1]);
ylim([10 36]);
set(gca,'FontSize',16)
label_x=xlabel('$R_{f} \ [\Omega]$','Interpreter','latex','FontSize',22,'HorizontalAlignment','center');
%xlabel('\it{Capacitance C} [\it{\muF}]','FontSize',18,'HorizontalAlignment','center');
set(label_x,'rotation',0);
label_h=ylabel('$A_{1i} \ [dB]$','Interpreter','latex','FontSize',22,'HorizontalAlignment','center');
set(label_h,'rotation',90);
%legend('\it{Q_L}=1000','\it{Q_L}=800','\it{Q_L}=600','\it{Q_L}=300','Orientation','horizontal','Location','southeast','FontSize',20);
legend('$Q_L=800$','$Q_L=600$','$Q_L=400$','$Q_L=200$','Interpreter','latex','Orientation','horizontal','Location','southeast','FontSize',20)
legend('boxoff')
My_LGD = legend;
My_LGD.NumColumns = 2;    % Show legends in 5 lines
h=gcf;
set(h,'Position',[200 200 720 570]);
%grid on
grid minor

ar = annotation("arrow");
c = ar.Color;
ar.Color = "black";
ar.LineStyle="--";
ar.LineWidth=3;
ar.X=[0.31 0.395];
ar.Y=[0.205 0.30];
text(0.285,12,{'$C_f = 1\mu F$'},'Interpreter','latex','FontSize',25,'HorizontalAlignment','center');
ar = annotation("arrow");
c = ar.Color;
ar.Color = "black";
ar.LineStyle="--";
ar.LineWidth=3;
ar.X=[0.64 0.56];
ar.Y=[0.53 0.435];
text(0.71,24.1,{'$C_f = 10\mu F$'},'Interpreter','latex','FontSize',25,'HorizontalAlignment','center');
