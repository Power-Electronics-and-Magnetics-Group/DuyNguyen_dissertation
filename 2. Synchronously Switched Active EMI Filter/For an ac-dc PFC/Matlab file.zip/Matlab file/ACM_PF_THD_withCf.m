clc
clear

format long
%yellow_color = '#e2d810';
yellow_color = '#CbC000';
red_color = '#ff0000'; %'#d9138a';
blue_color = '#0000ff';%'#12a4d9';
black_color = '#322e2f';
magenta_color = '#d9138a';
cyan_color = '#12a4d9';
orange_color = '#D95319';

%% ACM: current attenuation with Cf
Cf= [1 3 5 7 9 11 13]*1e-6;

THD_measured=[4.03 4.18 4.33 4.72 5.33 6.04 6.84];
THD_analysis=[0.02 0.37 0.9 1.61 2.65 3.7 4.73];
P=[301.2 301.6 301.8 300.8 301 301 302.3];
S=[302.2 303 303.9 303.7 304.8 305.9 308.1];
PF=P./S;

%%
figure();
stem(Cf*1e6,PF,'o','filled','Color' , cyan_color, 'LineStyle', 'none' ,'LineWidth',7);
hold on
ylim([0.9 1]);
xlim([0.5 13.5]);
set(gca,'FontSize',16)
label_x=xlabel('$Capacitance \ C_f \ [\mu F]$','Interpreter','latex','FontSize',22,'HorizontalAlignment','center');
set(label_x,'rotation',0);
label_h=ylabel('$PF$','Interpreter','latex','FontSize',22,'HorizontalAlignment','center');
set(label_h,'rotation',90);
yyaxis right
stem(Cf*1e6,THD_measured,'o','filled','Color' , black_color, 'LineStyle', 'none' ,'LineWidth',7);
%stem(Cf*1e6,THD_analysis,'o','filled','Color' , black_color, 'LineStyle', 'none' ,'LineWidth',6);
ylim([4 8]);
ax = gca;
ax.YAxis(1).Color = 'k';
ax.YAxis(2).Color = 'k';
hold off
label_h=ylabel('$THD \ [\%]$','Interpreter','latex','FontSize',22,'HorizontalAlignment','center');
set(label_h,'rotation',90);
%legend('\it{Q_L}=1000','\it{Q_L}=800','\it{Q_L}=600','\it{Q_L}=300','\it{THD}','Orientation','horizontal','Location','southeast','FontSize',20);
%legend('Experimental Result','Analytic Result','Interpreter','latex','Orientation','horizontal','Location','southeast','FontSize',20)
%legend('boxoff')
%My_LGD = legend;
%My_LGD.NumColumns = 1;    % Show legends in 5 lines
legend('PF','THD','Interpreter','latex','Orientation','horizontal','Location','southeast','FontSize',22)
legend('boxoff')
My_LGD = legend;
My_LGD.NumColumns = 1;    % Show legends in 5 lines
h=gcf;
set(h,'Position',[200 200 700 360]);
grid on
%grid minor
