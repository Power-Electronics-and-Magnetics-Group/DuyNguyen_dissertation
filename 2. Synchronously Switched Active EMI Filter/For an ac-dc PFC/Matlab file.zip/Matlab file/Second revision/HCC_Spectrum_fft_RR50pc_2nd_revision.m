clc
clear

format long
%yellow_color = '#e2d810';
yellow_color = '#CbC000';
red_color = '#ff0000'; %'#d9138a';
blue_color = '#0000ff';%'#12a4d9';
black_color = '#322e2f';
magenta_color = '#d9138a';
cyan_color = '#12a4d9';
orange_color = '#D95319';

%% For ACM Cf=
format long
Ro=50;

data = csvread('HCC_CONV_50pc.csv',1); % Read the data
f1 = data(2:end,1);
Iconv=data(2:end,2);     % iconv 
Iconv_c=(2.*50.*1e-3.*10.^(Iconv./10)).^0.5.*10;
Iconv_uV=20.*log10(Iconv_c.*Ro./1e-6);

%%

data = csvread('HCC_CONV_50pc_5uF_shunt.csv',1); % Read the data
f4 = data(2:end,1);
Iconv=data(2:end,2);     % iconv 
Iconv_c=(2.*50.*1e-3.*10.^(Iconv./10)).^0.5.*10;
Iconv_uV_xx=20.*log10(Iconv_c.*Ro./1e-6);

data = csvread('HCC_CONV_50pc_Lin_Cin.csv',1); % Read the data
f6 = data(2:end,1);
Iconv=data(2:end,2);     % iconv 
Iconv_c=(2.*50.*1e-3.*10.^(Iconv./10)).^0.5.*10;
Iconv_uV_Lin_Cin=20.*log10(Iconv_c.*Ro./1e-6);
Iconv_uV_Lin_Cin (211:end)=Iconv_uV_Lin_Cin (211:end)-6;

data = csvread('HCC_S_50pc_5uF.csv',1); % Read the data
f2 = data(2:end,1);
Is_1uF=data(2:end,2);     % is
Is_1uF_c=(2.*50.*1e-3.*10.^(Is_1uF./10)).^0.5.*10;
Is_1uF_uV=20.*log10(Is_1uF_c.*Ro./1e-6);

data = csvread('HCC_S_50pc_15uF.csv',1); % Read the data
f3 = data(2:end,1);
Is_10uF=data(2:end,2);     % is  
Is_10uF_c=(2.*50.*1e-3.*10.^(Is_10uF./10)).^0.5.*10;
Is_10uF_uV=20.*log10(Is_10uF_c.*Ro./1e-6);

data = csvread('HCC_S_50pc_Lin_Cin_full_filter.csv',1); % Read the data
f5 = data(2:end,1);
Is_10uF=data(2:end,2);     % is  
Is_10uF_c=(2.*50.*1e-3.*10.^(Is_10uF./10)).^0.5.*10;
Is_full_filter=20.*log10(Is_10uF_c.*Ro./1e-6)-6;

figure();

semilogx(f1,Iconv_uV,'Color' , black_color,'LineWidth',2.2);
%%
hold on

semilogx(f2,Is_1uF_uV,'Color' , yellow_color,'LineWidth',2.2);
%%
semilogx(f3,Is_10uF_uV,'Color' , magenta_color,'LineWidth',2.2);
%%
%semilogx(f4,Iconv_uV_xx,'Color' , red_color,'LineWidth',2.2);

semilogx(f6,Iconv_uV_Lin_Cin,'Color' , cyan_color,'LineWidth',2.2);

semilogx(f5,Is_full_filter,'Color' , blue_color,'LineWidth',2.2);

x = [150e3 500e3 500e3 5e6 5e6 30e6];
y = [66 56 56 56 60 60]
plot(x,y,'Color' , black_color,'LineWidth',4);
%ylim([-1.4 5.2]);
xlim([50e3 30e6]);
ylim([35 180]);
set(gca,'FontSize',16)
label_h=ylabel('$Magnitude \ [dB \mu V]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_h,'rotation',90);
label_x=xlabel('$Frequency \ [Hz]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_x,'rotation',0);
%text(6.8,4.5,{'$\mathcal{R}=0.2$'},'Interpreter','latex','Color', orange_color,'FontSize',19,'HorizontalAlignment','center');
legend('$i_{conv}$','$i_s, C_f=5\mu F$','$i_s, C_f=15\mu F$','$i_{s}, L_{in}=5.1\mu H, C_{in}=5\mu F$, w/o AEF','$i_{s}, L_{in}=250\mu H, C_{in}=5\mu F$, w/ AEF','Interpreter','latex','Orientation','horizontal','Location','southeast','FontSize',20)
legend('boxoff')
My_LGD = legend;
My_LGD.NumColumns = 1;    % Show legends in 5 lines
grid minor
h=gcf;
set(h,'Position',[200 200 850 600]);
text(9e6,105,{'$\mathcal{R}=0.5$'},'Interpreter','latex','Color', orange_color,'FontSize',30,'HorizontalAlignment','center');
