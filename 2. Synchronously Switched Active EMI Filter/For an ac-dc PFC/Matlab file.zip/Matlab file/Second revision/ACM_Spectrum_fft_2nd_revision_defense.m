clc
clear

format long
%yellow_color = '#e2d810';
yellow_color = '#CbC000';
red_color = '#ff0000'; %'#d9138a';
blue_color = '#0000ff';%'#12a4d9';
black_color = '#322e2f';
magenta_color = '#d9138a';
cyan_color = '#12a4d9';
orange_color = '#D95319';

%% For ACM Cf=
format long
Ro=50;

data = csvread('ACM_CONV.csv',1); % Read the data
f1 = data(2:end,1);
Iconv=data(2:end,2);     % iconv 
Iconv_c=(2.*50.*1e-3.*10.^(Iconv./10)).^0.5.*10;
Iconv_uV=20.*log10(Iconv_c.*Ro./1e-6);



data = csvread('ACM_CONV_Lin_Cin.csv',1); % Read the data
f4 = data(2:end,1);
Iconv=data(2:end,2);     % iconv 
Iconv_c=(2.*50.*1e-3.*10.^(Iconv./10)).^0.5.*10;
Iconv_uV_xx=20.*log10(Iconv_c.*Ro./1e-6)-6;


data = csvread('ACM_S_1uF_1.csv',1); % Read the data
f2 = data(2:end,1);
Is_1uF=data(2:end,2);     % is
Is_1uF_c=(2.*50.*1e-3.*10.^(Is_1uF./10)).^0.5.*10;
Is_1uF_uV=20.*log10(Is_1uF_c.*Ro./1e-6);

data = csvread('ACM_S_10uF_1.csv',1); % Read the data
f3 = data(2:end,1);
Is_10uF=data(2:end,2);     % is  
Is_10uF_c=(2.*50.*1e-3.*10.^(Is_10uF./10)).^0.5.*10;
Is_10uF_uV=20.*log10(Is_10uF_c.*Ro./1e-6);

data = csvread('ACM_CONV_Lin_Cin_full_filter.csv',1); % Read the data
f11 = data(2:end,1);
Iconv=data(2:end,2);     % iconv 
Iconv_c=(2.*50.*1e-3.*10.^(Iconv./10)).^0.5.*10;
Iconv_uV_full=20.*log10(Iconv_c.*Ro./1e-6)-6;

figure();

semilogx(f1,Iconv_uV,'Color' , black_color,'LineWidth',2.2);

hold on

semilogx(f2,Is_1uF_uV,'Color' , yellow_color,'LineWidth',2.2);

%semilogx(f3,Is_10uF_uV,'Color' , magenta_color,'LineWidth',2.2);

%semilogx(f4,Iconv_uV_xx,'Color' , cyan_color,'LineWidth',2.2);

semilogx(f11,Iconv_uV_full,'Color' , blue_color,'LineWidth',2.2);

%%
data = csvread('ACM_S_1uF_1.csv',1); % Read the data
f2 = data(2:120,1);
Is_1uF=data(2:120,2);     % is
Is_1uF_c=(2.*50.*1e-3.*10.^(Is_1uF./10)).^0.5.*10;
Is_1uF_uV=20.*log10(Is_1uF_c.*Ro./1e-6);
semilogx(f2,Is_1uF_uV,'Color' , yellow_color,'LineWidth',2.2);

%data = csvread('ACM_S_10uF_1.csv',1); % Read the data
%f3 = data(2:120,1);
%Is_10uF=data(2:120,2);     % is  
%Is_10uF_c=(2.*50.*1e-3.*10.^(Is_10uF./10)).^0.5.*10;
%Is_10uF_uV=20.*log10(Is_10uF_c.*Ro./1e-6);
%semilogx(f3,Is_10uF_uV,'Color' , magenta_color,'LineWidth',2.2);

%%


data = csvread('ACM_CONV.csv',1); % Read the data
f1 = data(2:60,1);
Iconv=data(2:60,2);     % iconv 
Iconv_c=(2.*50.*1e-3.*10.^(Iconv./10)).^0.5.*10;
Iconv_uV=20.*log10(Iconv_c.*Ro./1e-6);
semilogx(f1,Iconv_uV,'Color' , black_color,'LineWidth',2.2);

%data = csvread('ACM_CONV_Lin_Cin.csv',1); % Read the data
%f4 = data(2:60,1);
%Iconv=data(2:60,2);     % iconv 
%Iconv_c=(2.*50.*1e-3.*10.^(Iconv./10)).^0.5.*10;
%Iconv_uV_xx=20.*log10(Iconv_c.*Ro./1e-6)-6;
%semilogx(f4,Iconv_uV_xx,'Color' , cyan_color,'LineWidth',2.2);

data = csvread('ACM_S_1uF_1.csv',1); % Read the data
f2 = data(2:60,1);
Is_1uF=data(2:60,2);     % is
Is_1uF_c=(2.*50.*1e-3.*10.^(Is_1uF./10)).^0.5.*10;
Is_1uF_uV=20.*log10(Is_1uF_c.*Ro./1e-6);
semilogx(f2,Is_1uF_uV,'Color' , yellow_color,'LineWidth',2.2);

data = csvread('ACM_CONV.csv',1); % Read the data
f1 = data(2:60,1);
Iconv=data(2:60,2);     % iconv 
Iconv_c=(2.*50.*1e-3.*10.^(Iconv./10)).^0.5.*10;
Iconv_uV=20.*log10(Iconv_c.*Ro./1e-6);
semilogx(f1,Iconv_uV,'Color' , black_color,'LineWidth',2.2);


semilogx(f11,Iconv_uV_full,'Color' , blue_color,'LineWidth',2.2);

%%
x = [150e3 500e3 500e3 5e6 5e6 30e6];
y = [66 56 56 56 60 60]
plot(x,y,'Color' , black_color,'LineWidth',4);
%ylim([-1.4 5.2]);
xlim([50e3 30e6]);
ylim([35 180]);
set(gca,'FontSize',16)
label_h=ylabel('$Magnitude \ [dB \mu V]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_h,'rotation',90);
label_x=xlabel('$Frequency \ [Hz]$','Interpreter','latex','FontSize',20,'HorizontalAlignment','center');
set(label_x,'rotation',0);
%text(6.8,4.5,{'$\mathcal{R}=0.2$'},'Interpreter','latex','Color', orange_color,'FontSize',19,'HorizontalAlignment','center');
legend('$i_{conv}$, w/o AEF','$i_s$, AEF w/ $C_f=1\mu F$','$i_{s}$, AEF w/ $C_f=1\mu F$ \& $L_{in}=250\mu H, C_{in}=15\mu F$','Interpreter','latex','Orientation','horizontal','Location','southeast','FontSize',18)
legend('boxoff')
My_LGD = legend;
My_LGD.NumColumns = 1;    % Show legends in 5 lines
grid minor
h=gcf;
set(h,'Position',[200 200 850 600]);
