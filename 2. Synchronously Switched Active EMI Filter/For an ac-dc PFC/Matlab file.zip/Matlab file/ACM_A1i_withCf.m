clc
clear

format long
%yellow_color = '#e2d810';
yellow_color = '#CbC000';
red_color = '#ff0000'; %'#d9138a';
blue_color = '#0000ff';%'#12a4d9';
black_color = '#322e2f';
magenta_color = '#d9138a';
cyan_color = '#12a4d9';
orange_color = '#D95319';

%% ACM: current attenuation with Cf
Cf= [1 3 5 7 9 11 13]*1e-6;
%A1s=[-22.2 -32.5 -35.3 -34.6 -35.3 -34.6 -34.3];
A1conv=[-15.26 -15.56 -14.8 -14.81 -14.52 -14.52 -14.52];  % This is results from spectrum analyzer with 100mV/A attenuation
A1s=[-41.63 -43.67 -44.2 -45.31 -44.3 -44.25 -43.2];

A1i=A1s-A1conv;
%A1i_analysis=[23 31.6 34.3 35.6 36.6 36.95 37.5]; %Rf=0.05
A1i_analysis=[23 29 32.3 33.5 34.2 34.7 35.2]; %Rf=0.02

%%
figure();
stem(Cf*1e6,abs(A1i),'o','filled','Color' , magenta_color, 'LineStyle', 'none' ,'LineWidth',7);
hold on
stem(Cf*1e6,A1i_analysis,'o','filled','Color' , black_color, 'LineStyle', 'none' ,'LineWidth',7);
ylim([0 40]);
xlim([0.5 13.5]);

set(gca,'FontSize',16)
label_x=xlabel('$Capacitance \ C_f \ [\mu F]$','Interpreter','latex','FontSize',22,'HorizontalAlignment','center');
set(label_x,'rotation',0);
label_h=ylabel('$A_{1i} \ [dB]$','Interpreter','latex','FontSize',22,'HorizontalAlignment','center');
set(label_h,'rotation',90);
%legend('\it{Q_L}=1000','\it{Q_L}=800','\it{Q_L}=600','\it{Q_L}=300','\it{THD}','Orientation','horizontal','Location','southeast','FontSize',20);
legend('Experimental Result','Analytic Result','Interpreter','latex','Orientation','horizontal','Location','southeast','FontSize',20)
legend('boxoff')
My_LGD = legend;
My_LGD.NumColumns = 1;    % Show legends in 5 lines
h=gcf;
set(h,'Position',[200 200 700 360]);
grid on
%grid minor
