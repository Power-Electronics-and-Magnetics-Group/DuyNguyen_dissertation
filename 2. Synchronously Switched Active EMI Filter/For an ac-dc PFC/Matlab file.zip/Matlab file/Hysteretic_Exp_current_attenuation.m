clc
clear

format long
%yellow_color = '#e2d810';
yellow_color = '#CbC000';
red_color = '#ff0000'; %'#d9138a';
blue_color = '#0000ff';%'#12a4d9';
black_color = '#322e2f';
magenta_color = '#d9138a';
cyan_color = '#12a4d9';
orange_color = '#D95319';

%%
format long
data = csvread('p.csv',1); % Read the data
freq = data(1:end,1);
CH1=data(1:end,2)-20;  % is

figure();
semilogx(data,CH1,'Color' , magenta_color,'LineWidth',2.8);
xlim([50e3 30e6]);
ylim([-80 0]);
h=gcf;
set(h,'Position',[200 200 720 570]);
grid minor
%%

dbm_measure=-32;
V2=10^(dbm_measure/10)*1e-3;
V1=V2/10^(-30/20);
is=V1/50;
dBm=10*log10(is/1e-3)